package kr.co.gugu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class TempletController {

	// TODO
	@RequestMapping(value = "/templet/blank", method = RequestMethod.GET)
	public String blank() {
		return "/templet/blank";
	}
	
	@RequestMapping(value = "/templet/error", method = RequestMethod.GET)
	public String error() {
		return "/templet/error";
	}

	@RequestMapping(value = "/templet/buttons", method = RequestMethod.GET)
	public String buttons() {
		return "/templet/buttons";
	}

	@RequestMapping(value = "/templet/cards", method = RequestMethod.GET)
	public String cards() {
		return "/templet/cards";
	}

	
	@RequestMapping(value = "/templet/tables", method = RequestMethod.GET)
	public String tables() {
		return "/templet/tables";
	}

	@RequestMapping(value = "/templet/map", method = RequestMethod.GET)
	public String map() {
		return "/templet/map";
	}


	@RequestMapping(value = "/templet/border", method = RequestMethod.GET)
	public String border() {
		return "/templet/border";
	}

	@RequestMapping(value = "/templet/color", method = RequestMethod.GET)
	public String color() {
		return "/templet/color";
	}

	@RequestMapping(value = "/templet/login", method = RequestMethod.GET)
	public String login() {
		return "/templet/login";
	}

	@RequestMapping(value = "/templet/forgotPW", method = RequestMethod.GET)
	public String forgotPW() {
		return "/templet/forgotPW";
	}

	@RequestMapping(value = "/templet/other", method = RequestMethod.GET)
	public String other() {
		return "/templet/other";
	}
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String index() {
		return "/index";
	}
}
