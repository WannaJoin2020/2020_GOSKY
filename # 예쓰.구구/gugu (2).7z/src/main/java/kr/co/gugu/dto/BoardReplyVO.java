package kr.co.gugu.dto;

import java.util.Date;

public class BoardReplyVO {

	private int reno;				//댓글번호
	private String rewriter;		//작성자	
	private String recontent;		//내용
	private int bno;				//글번호
	private int redel;				//삭제여부
	
	public int getReno() {
		return reno;
	}
	public void setReno(int reno) {
		this.reno = reno;
	}
	public String getRewriter() {
		return rewriter;
	}
	public void setRewriter(String rewriter) {
		this.rewriter = rewriter;
	}
	public String getRecontent() {
		return recontent;
	}
	public void setRecontent(String recontent) {
		this.recontent = recontent;
	}
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public int getRedel() {
		return redel;
	}
	public void setRedel(int redel) {
		this.redel = redel;
	}
	public Date getRedate() {
		return redate;
	}
	public void setRedate(Date redate) {
		this.redate = redate;
	}
	private Date redate;			//날짜
	
	
}
