//advice : 공통업무를 지원하는 클래스
//핵심업무가 실행하기 전 / 후에 처리 = 공통업무 (aop)라고 이해하면됨

package kr.co.gugu.common;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

// @before(해당 핵심업무가 호출되기 전)
@Component
@Aspect
public class LoggerAspect {
	protected Logger log = LoggerFactory.getLogger(LoggerAspect.class);

	@Around("execution(* kr.co.gugu.controllrt.*Controller.*(..))")
	public Object logprint(ProceedingJoinPoint joinPoint) throws Throwable {
		Object result = null;

		// 핵심업무 실행전
		long start = System.currentTimeMillis();

		// 핵심업무 실행
		result = joinPoint.proceed();

		// 핵심업무 실행후 (controller)
		long end = System.currentTimeMillis();

		log.info("수행시간 : " + (end-start));
		return result;
	}
}
