INSERT INTO `gugu`.`reply`
(`reno`,
`rewriter`,
`recontent`,
`bno`,
`redel`,
`redate`,
`replycnt`)
VALUES
(<{reno: }>,
<{rewriter: }>,
<{recontent: }>,
<{bno: }>,
<{redel: 0}>,
<{redate: CURRENT_TIMESTAMP}>,
<{replycnt: 0}>);
