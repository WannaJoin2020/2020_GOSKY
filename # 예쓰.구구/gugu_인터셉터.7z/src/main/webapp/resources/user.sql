INSERT INTO `gugu`.`user`
(`userno`,
`id`,
`password`,
`name`)
VALUES
(<{userno: }>,
<{id: }>,
<{password: }>,
<{name: }>);
