package kr.co.gugu.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.JsonNode;

import kr.co.gugu.service.KakaoAPI;
import kr.co.gugu.service.LoginService;

@Controller
public class LoginController {

	@Inject
	LoginService loginService;

	@Autowired
	private KakaoAPI kakao;

	// 로그인(초기화면)
	@RequestMapping(value = "/login/login", method = RequestMethod.GET)
	public String login() {
		return "/login/login";
	}

	// 로그인
	@RequestMapping(value = "/login/login", method = RequestMethod.POST)
	public String login(@RequestParam Map<String, String> map, HttpSession session) throws Exception {
		System.out.println("========== login 메소드 ========");
		System.out.println(map.get("id") + " , " + map.get("password"));
		Map user = loginService.login(map);
		if (user == null) {
			System.out.println("로그인 x 다시 시도해주세요");
			return "login/login";
		} else {
			session.setAttribute("user", user);
			System.out.println("로그인성공o");
			return "redirect:/";
		}
	}

	// 카카오로그인
	@RequestMapping(value = "/login/kakao")
	public String kakaologin(@RequestParam("code") String code, HttpSession session) {
		String access_Token = kakao.getAccessToken(code);
		HashMap<String, Object> userInfo = kakao.getUserInfo(access_Token);
		System.out.println("login Controller : " + userInfo);

		// 클라이언트의 이메일이 존재할 때 세션에 해당 이메일과 토큰 등록
		if (userInfo.get("email") != null) {
			session.setAttribute("userId", userInfo);
			session.setAttribute("access_Token", access_Token);
			
		}
		return "/index";
	}

	// 로그아웃
	@RequestMapping(value = "/login/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		return "/index";
	}
	
	// 카카오 로그아웃
	@RequestMapping(value = "/login/kakaologout")
		public String kakaologout(HttpSession session) {
		    kakao.kakaoLogout((String)session.getAttribute("access_Token"));
		    session.removeAttribute("access_Token");
		    session.removeAttribute("userId");
			session.invalidate();
		    return "/index";
		}

	// 회원가입
	@RequestMapping(value = "/login/register", method = RequestMethod.GET)
	public String register() {
		return "/login/register";
	}

	// 패스워드찾기
	@RequestMapping(value = "/login/forgotPW", method = RequestMethod.GET)
	public String forgotPW() {
		return "/login/forgotPW";
	}

}
