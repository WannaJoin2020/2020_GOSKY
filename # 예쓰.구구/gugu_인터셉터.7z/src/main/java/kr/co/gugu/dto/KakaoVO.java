package kr.co.gugu.dto;

public class KakaoVO {

	private String profile;
	private String account_email;
	private String gender;
	private int age_range;
	
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public String getAccount_email() {
		return account_email;
	}
	public void setAccount_email(String account_email) {
		this.account_email = account_email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge_range() {
		return age_range;
	}
	public void setAge_range(int age_range) {
		this.age_range = age_range;
	}
	

}
