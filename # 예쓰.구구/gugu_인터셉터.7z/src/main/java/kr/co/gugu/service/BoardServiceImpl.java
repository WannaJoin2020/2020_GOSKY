package kr.co.gugu.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import kr.co.gugu.dao.BoardDAO;
import kr.co.gugu.dto.BoardReplyVO;
import kr.co.gugu.dto.BoardVO;
import kr.co.gugu.dto.Criteria;

@Service
public class BoardServiceImpl implements BoardService {

	@Inject
	private BoardDAO boardDAO;

	@Inject
	public BoardServiceImpl(BoardDAO boardDAO) {
		this.boardDAO = boardDAO;
	}

	// 전체보기
	@Override
	public List<BoardVO> listAll() throws Exception {
		return boardDAO.listAll();
	}

	// 조회수증가(보기)
	@Override
	public BoardVO increaseCnt(int bno) throws Exception {
		boardDAO.increaseCnt(bno);
		return boardDAO.view(bno);
	}

	// 상세조회->수정할때 보기
	@Override
	public BoardVO view(int bno) throws Exception {
		return boardDAO.view(bno);
	}

	// 글쓰기
	@Override
	public int insert(BoardVO vo) throws Exception {
		return boardDAO.insert(vo);
	}

	// 글수정
	@Override
	public int update(BoardVO vo) throws Exception {
		return boardDAO.update(vo);
	}

	// 글삭제
	@Override
	public int delete(int bno) throws Exception {
		return boardDAO.delete(bno);
	}

	// 해당 댓글목록보기
	@Override
	public List<BoardReplyVO> replyList(int bno) throws Exception {
		return boardDAO.replyList(bno);
	}

	// 댓글상세보기
	@Override
	public BoardReplyVO replyView(int reno) throws Exception {
		return boardDAO.replyView(reno);
	}

//	// 댓글작성
//	@Override
//	public int replyWrite(BoardReplyVO boardreplyVO) throws Exception {
//		return boardDAO.replyWrite(boardreplyVO);
//	}

	// 댓글수정
	@Override
	public int replyUpdate(BoardReplyVO boardreplyVO) throws Exception {
		return boardDAO.replyUpdate(boardreplyVO);
	}

//	// 댓글삭제
//	@Override
//	public int replyDelete(int reno) throws Exception {
//		return boardDAO.replyDelete(reno);
//	}

//============================================================================================
	// TODO
	// 페이징처리
	@Override
	public List<BoardVO> listCriteria(Criteria criteria) throws Exception {
		return boardDAO.listCriteria(criteria);
	}
	// =================================================================================

	// 댓글작성
	@Transactional // 트랜잭션 처리, 두가지 작업을 할때.. 댓글이추가되거나 삭제되면 -> 게시글 댓글 수 수정
	@Override
	public void replyWrite(BoardReplyVO boardreplyVO) throws Exception {
		boardDAO.replyWrite(boardreplyVO); // 댓글 등록
		boardDAO.replyCnt(boardreplyVO.getBno(), 1); // 댓글 갯수 증가
	}

	// 댓글 갯수 제거
	@Transactional
	@Override
	public void replyDelete(Integer reno) throws Exception {
		int bno = boardDAO.getBno(reno); // 댓글의 게시물 번호 조회
		boardDAO.replyDelete(reno); // 댓글 삭제
		boardDAO.replyCnt(bno, -1); // 댓글 갯수 감소
	}
}
