package kr.co.gugu.dao;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import kr.co.gugu.dto.KakaoVO;

@Repository
public class LoginDAOImpl implements LoginDAO{
	
	
	@Inject
	SqlSession sqlSession;

	@Override
	public Map login(Map<String, String> map) throws Exception {
		System.out.println("디비들어오니!!!!!!!!!!!!!!!!!!");
		return sqlSession.selectOne("login.login",map);
	}

	@Override
	public List<KakaoVO> kakaoUsers(KakaoVO kakaoVo) throws Exception {
		return sqlSession.selectList("login.listAll");
	}

}
