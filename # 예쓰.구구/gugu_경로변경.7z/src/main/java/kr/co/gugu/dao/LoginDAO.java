package kr.co.gugu.dao;

import java.util.List;
import java.util.Map;

import kr.co.gugu.dto.KakaoVO;

public interface LoginDAO {

	public Map login(Map<String, String> map) throws Exception;

    List<KakaoVO> kakaoUsers(KakaoVO kakaoVo) throws Exception;

}
