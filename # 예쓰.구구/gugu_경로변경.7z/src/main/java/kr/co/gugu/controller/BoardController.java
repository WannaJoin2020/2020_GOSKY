package kr.co.gugu.controller;

import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.co.gugu.dto.BoardReplyVO;
import kr.co.gugu.dto.BoardVO;
import kr.co.gugu.dto.Criteria;
import kr.co.gugu.dto.PageMaker;
import kr.co.gugu.service.BoardService;

@Controller
public class BoardController {

	@Inject
	BoardService boardService;

	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);

	// 게시판목록 전체보기
	@RequestMapping(value = "board/listAll", method = RequestMethod.GET)
	public String listAll(Model model, Criteria criteria) throws Exception {
		logger.info("listPaging  ========================================");
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(criteria);
		;
		pageMaker.setTotalCount(1000);
		;

		model.addAttribute("list", boardService.listCriteria(criteria));
		model.addAttribute("pageMaker", pageMaker);
		return "board/listAll";
	}

//	@RequestMapping(value = "/board/listAll", method = RequestMethod.GET)
//	public ModelAndView listAll() throws Exception {
//		ModelAndView mav = new ModelAndView();
//		List<BoardVO> list = boardService.listAll();
//		mav.addObject("list", list);
//		mav.setViewName("board/listAll");
//		return mav;
//	}

	// 게시글쓰기(초기화면)
	@RequestMapping(value = "board/write", method = RequestMethod.GET)
	public String write() throws Exception {
		return "board/write";
	}

	// 게시글쓰기
	@RequestMapping(value = "board/write", method = RequestMethod.POST)
	public String write(BoardVO vo, RedirectAttributes rttr) throws Exception {
		int r = boardService.insert(vo);
		if (r > 0) {
		}return "redirect:listAll";
	}

	// 게시글보기
	@RequestMapping(value = "board/view", method = RequestMethod.GET)
	public String view(@RequestParam("bno") int bno, Model model) throws Exception {
//		boardService.increaseCnt(bno);
//		BoardVO vo = boardService.view(bno);
		BoardVO vo = boardService.increaseCnt(bno);
		model.addAttribute("board", vo);

		// 댓글목록조회
		List<BoardReplyVO> replylist = boardService.replyList(bno);
		model.addAttribute("replylist", replylist);
		return "board/view";
	}

	// 게시글수정(초기화면)
	@RequestMapping(value = "board/update", method = RequestMethod.GET)
	public String update(@RequestParam("bno") int bno, Model model) throws Exception {
		BoardVO vo = boardService.view(bno);
		model.addAttribute("board", vo);
		return "board/update";
	}

	// 게시글수정
	@RequestMapping(value = "board/update", method = RequestMethod.POST)
	public String update(BoardVO vo, RedirectAttributes rttr) throws Exception {
		int r = boardService.update(vo);
		if (r > 0) {
			rttr.addFlashAttribute("msg", "게시글 수정에 성공하였습니다.");
		}
		return "redirect:listAll";
	}

	// 게시글삭제
	@RequestMapping(value = "board/delete", method = RequestMethod.GET)
	public String delete(@RequestParam("bno") int bno, RedirectAttributes rttr) throws Exception {
		int r = boardService.delete(bno);
		if (r > 0) {
			rttr.addFlashAttribute("msg", "게시글이 삭제되었습니다.");
		}
		return "redirect:listAll";
	}

//=====================================================================================================
	// TODO
	// 댓글상세보기

	// 댓글작성(초기화면)
	@RequestMapping(value = "board/reply", method = RequestMethod.GET)
	public String reply() {
		return "board/replyWrite";
	}

//	// 댓글작성
//		@RequestMapping(value = "board/reply", method = RequestMethod.POST)
//		public String reply(BoardReplyVO boardReplyVO) throws Exception {
//			int r = boardService.replyWrite(boardReplyVO);
//			if (r > 0) {
//				return "redirect:view?bno=" + boardReplyVO.getBno();
//			}
//			return "board/replyWrite";
//		}
	// 댓글작성
	@RequestMapping(value = "board/reply", method = RequestMethod.POST)
	public String reply(BoardReplyVO boardReplyVO) throws Exception {
		boardService.replyWrite(boardReplyVO);
		return "redirect:view?bno=" + boardReplyVO.getBno();
	}

	// 댓글수정(초기화면)
	@RequestMapping(value = "board/replyUpdate", method = RequestMethod.GET)
	public String replyUpdate(@RequestParam("reno") int reno, Model model) throws Exception {
		BoardReplyVO boardReplyVO = boardService.replyView(reno);
		model.addAttribute("boardreply", boardReplyVO);
		return "board/replyUpdate";
	}

	// 댓글수정
	@RequestMapping(value = "board/replyUpdate", method = RequestMethod.POST)
	public String replyUpdate(BoardReplyVO boardReplyVO) throws Exception {
		int r = boardService.replyUpdate(boardReplyVO);
		if (r > 0) {
			return "redirect:listAll";
//			return "redirect:bview?bno=" + boardReplyVO.getBno();
		}
		return "redirect:listAll";
	}

//	// 댓글삭제
//	@RequestMapping(value = "board/replyDelete", method = RequestMethod.GET)
//	public String replyDelete(@RequestParam("bno") int bno, @RequestParam("reno") int reno, RedirectAttributes rttr)
//			throws Exception {
//		int r = boardService.replyDelete(reno);
//		if (r > 0) {
//			rttr.addFlashAttribute("msg", "댓글이 삭제되었습니다.");
//			return "redirect:view?bno=" + bno;
//		}
//		return "redirect:listAll";
//	}
//	
	// 댓글삭제
	@RequestMapping(value = "board/replyDelete", method = RequestMethod.GET)
	public String replyDelete(@RequestParam("bno") int bno, @RequestParam("reno") int reno, RedirectAttributes rttr)
			throws Exception {
		boardService.replyDelete(reno);
		return "redirect:listAll";
	}

//=====================================================================================================
	// TODO
	// function 기능 (컨트롤러 따로 만들기)
	@RequestMapping(value = "/function/blank", method = RequestMethod.GET)
	public String blank() {
		return "/function/blank";
	}

	@RequestMapping(value = "/function/button", method = RequestMethod.GET)
	public String button() {
		return "/function/button";
	}

	@RequestMapping(value = "/function/card", method = RequestMethod.GET)
	public String card() {
		return "/function/card";
	}

	@RequestMapping(value = "/function/charts", method = RequestMethod.GET)
	public String charts() {
		return "/function/charts";
	}

	@RequestMapping(value = "/function/tables", method = RequestMethod.GET)
	public String tables() {
		return "/function/tables";
	}

	@RequestMapping(value = "/function/map", method = RequestMethod.GET)
	public String map() {
		return "/function/map";
	}

	// utilities기능
	@RequestMapping(value = "/utilities/animation", method = RequestMethod.GET)
	public String animation() {
		return "/utilities/animation";
	}

	@RequestMapping(value = "/utilities/border", method = RequestMethod.GET)
	public String border() {
		return "/utilities/border";
	}

	@RequestMapping(value = "/utilities/color", method = RequestMethod.GET)
	public String color() {
		return "/utilities/color";
	}

	@RequestMapping(value = "/utilities/other", method = RequestMethod.GET)
	public String other() {
		return "/utilities/other";
	}

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String index() {
		return "/index";
	}
}
