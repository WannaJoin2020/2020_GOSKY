package kr.co.gugu.service;

import java.util.List;

import kr.co.gugu.dto.BoardReplyVO;
import kr.co.gugu.dto.BoardVO;
import kr.co.gugu.dto.Criteria;

public interface BoardService {

	// 전체목록조회
	public List<BoardVO> listAll() throws Exception;

	// 상세보기(조회수증가)
	public BoardVO increaseCnt(int bno) throws Exception;

	// 상세보기
	public BoardVO view(int bno) throws Exception;

	// 글쓰기
	public int insert(BoardVO vo) throws Exception;

	// 글수정
	public int update(BoardVO vo) throws Exception;

	// 글삭제
	public int delete(int bno) throws Exception;

	//해당 댓글목록보기
	public List<BoardReplyVO> replyList(int bno) throws Exception;

	// 댓글 상세보기
	public BoardReplyVO replyView(int reno) throws Exception;

	// 댓글쓰기
	public void replyWrite(BoardReplyVO boardreplyVO) throws Exception;

	// 댓글수정
	public int replyUpdate(BoardReplyVO boardreplyVO) throws Exception;

	// 댓글삭제
	public void replyDelete(Integer reno) throws Exception;
	
	//============================================================================================
//TODO
	// 페이징처리
	public List<BoardVO> listCriteria(Criteria criteria) throws Exception;

}