package kr.co.gugu.dao;

import java.util.List;

import kr.co.gugu.dto.BoardReplyVO;
import kr.co.gugu.dto.BoardVO;
import kr.co.gugu.dto.Criteria;

public interface BoardDAO {

	// 전체목록조회
	public List<BoardVO> listAll() throws Exception;

	// 상세보기(조회수증가)
	public int increaseCnt(int bno) throws Exception;

	// 상세보기
	public BoardVO view(int bno) throws Exception;

	// 글쓰기
	public int insert(BoardVO vo) throws Exception;

	// 글수정
	public int update(BoardVO vo) throws Exception;

	// 글삭제
	public int delete(int bno) throws Exception;

	// 해당 댓글목록보기
	public List<BoardReplyVO> replyList(int bno) throws Exception;

	// 댓글 상세보기
	public BoardReplyVO replyView(int reno) throws Exception;

	// 댓글쓰기
	public int replyWrite(BoardReplyVO boardreplyVO) throws Exception;

	// 댓글수정
	public int replyUpdate(BoardReplyVO boardreplyVO) throws Exception;

	// 댓글삭제
	public int replyDelete(int reno) throws Exception;

	//===================================================================
	// 페이징처리
	public List<BoardVO> listPaging(int page) throws Exception;

	public List<BoardVO> listCriteria(Criteria criteria) throws Exception;
	// =================================================================================
	//(댓글) 게시물 번호 조회
	int getBno(Integer reno) throws Exception;
	
	// 댓글 갯수 갱신
	public int replyCnt(Integer bno, int amount) throws Exception;


}
