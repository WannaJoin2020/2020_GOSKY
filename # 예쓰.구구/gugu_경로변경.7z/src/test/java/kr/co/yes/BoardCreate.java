package kr.co.yes;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import kr.co.gugu.dao.BoardDAO;
import kr.co.gugu.dto.BoardVO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/**/root-context.xml" })
public class BoardCreate {

	@Inject
	private BoardDAO boardDAO;

	@Test
	public void testInsert() throws Exception {

//    	 @Inject
//    	 private BoardDTO boardDTO;;

		BoardVO boardVO;
		for (int i = 1; i <= 1000; i++) {
			boardVO = new BoardVO();
			boardVO.setTitle("Test Title[ " + i + " ]");
			boardVO.setContent("Test Content[ " + i + " ]");
			boardVO.setId("Test Id[ " + i + " ]");
			
			boardDAO.insert(boardVO);		//글쓰기
		}
	}
}