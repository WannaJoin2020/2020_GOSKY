package kr.co.yes;

import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import kr.co.gugu.dao.BoardDAO;
import kr.co.gugu.dto.BoardVO;
import kr.co.gugu.dto.Criteria;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/**/root-context.xml" })
public class ArticleDAOTest {

	@Inject
	private BoardDAO boardDAO;

	private static final Logger logger = LoggerFactory.getLogger(ArticleDAOTest.class);

	@Test
	public void testListPaging() throws Exception {
		int page = 3;
		List<BoardVO> articles = boardDAO.listPaging(page);
		for (BoardVO board : articles) {
			logger.info(board.getBno() + " : " + board.getTitle() + " : " + board.getContent());
//			System.out.println(board.getBno() + " : " + board.getTitle() + " : " + board.getContent());
		}
	}
	@Test
	public void testListCrieria() throws Exception {
		Criteria criteria = new Criteria();
		criteria.setPage(3);
		criteria.setPerPageNum(20);
		List<BoardVO> listPaging = boardDAO.listCriteria(criteria);
		for (BoardVO board : listPaging) {
			System.out.println(board.getBno() + " : " + board.getTitle() + " : " + board.getContent());
		}

	}
}