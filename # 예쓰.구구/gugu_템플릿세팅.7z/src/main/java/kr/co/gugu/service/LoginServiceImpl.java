package kr.co.gugu.service;

import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import kr.co.gugu.dao.LoginDAO;

@Service
public class LoginServiceImpl implements LoginService{

	@Inject
	LoginDAO loginDao;

	@Override
	public Map login(Map<String, String> map) throws Exception {
		System.out.println("서비스들어오니!!!!!!!!!!!!!!!!!!");
		return loginDao.login(map);
	}
	
}
