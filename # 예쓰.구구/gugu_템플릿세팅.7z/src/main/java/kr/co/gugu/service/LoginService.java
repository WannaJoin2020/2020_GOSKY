package kr.co.gugu.service;

import java.util.Map;

import javax.servlet.http.HttpSession;

public interface LoginService {

	public Map login(Map<String, String> map) throws Exception;
}
