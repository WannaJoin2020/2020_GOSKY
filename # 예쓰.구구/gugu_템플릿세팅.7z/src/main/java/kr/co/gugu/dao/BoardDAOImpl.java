package kr.co.gugu.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import kr.co.gugu.dto.BoardReplyVO;
import kr.co.gugu.dto.BoardVO;
import kr.co.gugu.dto.Criteria;

@Repository
public class BoardDAOImpl implements BoardDAO {

	@Inject
	private SqlSession sqlSession;

	// 전체보기
	@Override
	public List<BoardVO> listAll() {
		return sqlSession.selectList("board.listAll");
	}

	// 조회수증가(보기)
	@Override
	public int increaseCnt(int bno) throws Exception {
		System.out.println("DAO 테스트");
		return sqlSession.update("board.increaseCnt", bno);
	}

	// 상세조회
	@Override
	public BoardVO view(int bno) throws Exception {
		return sqlSession.selectOne("board.view", bno);
	}

	// 글쓰기
	@Override
	public int insert(BoardVO vo) throws Exception {
		return sqlSession.insert("board.insert", vo);
	}

	// 글수정
	@Override
	public int update(BoardVO vo) throws Exception {
		return sqlSession.update("board.update", vo);
	}

	// 글삭제
	@Override
	public int delete(int bno) throws Exception {
		return sqlSession.update("board.delete", bno);
	}

	// 해당 댓글목록보기
	@Override
	public List<BoardReplyVO> replyList(int bno) throws Exception {
		System.out.println("DAO 테스트");
		return sqlSession.selectList("board.replyList", bno);
	}

	// 댓글상세보기
	@Override
	public BoardReplyVO replyView(int reno) throws Exception {
		System.out.println("DAO 테스트");
		return sqlSession.selectOne("board.replyView", reno);
	}

	// 댓글작성
	@Override
	public int replyWrite(BoardReplyVO boardreplyVO) throws Exception {
		System.out.println("DAO 테스트");
		return sqlSession.insert("board.replyWrite", boardreplyVO);
	}

	// 댓글수정
	@Override
	public int replyUpdate(BoardReplyVO boardreplyVO) throws Exception {
		System.out.println("DAO 테스트");
		return sqlSession.update("board.replyUpdate", boardreplyVO);
	}

	// 댓글삭제
	@Override
	public int replyDelete(int reno) throws Exception {
		System.out.println("DAO 테스트");
		return sqlSession.delete("board.replyDelete", reno);
	}

	// =================================================================================
	// 페이징처리
	@Override
	public List<BoardVO> listPaging(int page) throws Exception {
		if (page <= 0) {
			page = 1;
		}
		page = (page - 1) * 10;
		return sqlSession.selectList("board.listPaging", page);
	}

	@Override
	public List<BoardVO> listCriteria(Criteria criteria) throws Exception {
		System.out.println("DAO 테스트");
		return sqlSession.selectList("board.listCriteria", criteria);
	}
	// =================================================================================
	//(댓글) 게시물 번호 조회
	@Override
	public int getBno(Integer reno) throws Exception {
		System.out.println("DAO 테스트");
		return sqlSession.selectOne("board.getBno", reno);
	}
	
	// 댓글 갯수 갱신
	@Override
	public int replyCnt(Integer bno, int amount) throws Exception {

	    Map<String, Object> paramMap = new HashMap<>();
	    paramMap.put("bno", bno);
	    paramMap.put("amount", amount);

	    return sqlSession.update("board.replyCnt",paramMap);
	}

}
