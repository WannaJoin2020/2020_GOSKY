INSERT INTO `gugu`.`board`
(`bno`,
`title`,
`content`,
`id`,
`regdate`,
`increasecnt`,
`etc`,
`del`,
`replycnt`)
VALUES
(<{bno: }>,
<{title: }>,
<{content: }>,
<{id: }>,
<{regdate: CURRENT_TIMESTAMP}>,
<{increasecnt: 0}>,
<{etc: }>,
<{del: 0}>,
<{replycnt: }>);
