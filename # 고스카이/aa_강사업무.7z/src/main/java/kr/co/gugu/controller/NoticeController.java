package kr.co.gugu.controller;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.co.gugu.common.LoggerAspect;
import kr.co.gugu.domain.MemberDTO;
import kr.co.gugu.domain.NoticeDTO;
import kr.co.gugu.domain.PageMaker;
import kr.co.gugu.domain.Paging;
import kr.co.gugu.domain.SearchPaging;
import kr.co.gugu.service.NoticeService;
import kr.co.gugu.dao.MemberDAO;
import kr.co.gugu.dao.NoticeDAO;

@Controller
public class NoticeController {

	@Inject
	NoticeService noticeService;
	NoticeDAO noticeDAO;
	MemberDAO memberDAO;

	protected Logger log = LoggerFactory.getLogger(LoggerAspect.class);

	//목록, 검색처리
	@RequestMapping(value = "/NoticeList", method = RequestMethod.GET)
    public String NoticeSearch(@ModelAttribute("searchPaging") SearchPaging searchPaging,
                       Model model) throws Exception {

        PageMaker pageMaker = new PageMaker();
        pageMaker.setPaging(searchPaging);
        pageMaker.setTotalCount(noticeService.CountSearch(searchPaging));

        model.addAttribute("list", noticeService.Search(searchPaging));
        model.addAttribute("pageMaker", pageMaker);

		return "/notice/NoticeList";
    }

	
//	// 공지사항목록
//	@RequestMapping(value = "/NoticeList", method = RequestMethod.GET)
//	public String NoticeList(Model model, Paging paging) throws Exception {
//		
//		PageMaker pageMaker= new PageMaker();
//		pageMaker.setPaging(paging);
//		pageMaker.setTotalCount(noticeService.CountPaging(paging));
//		
//		model.addAttribute("list", noticeService.Paging(paging));
//		model.addAttribute("pageMaker", pageMaker);
//		return "/notice/NoticeList";
//		
////		ModelAndView mav = new ModelAndView();
////		List<NoticeDTO> list = noticeService.NoticeList();
////		mav.setViewName("/notice/NoticeList");
////		mav.addObject("list", list);
////		return mav;
//	}
	
	// 공지사항 글쓰기
	@RequestMapping(value = "/NoticeWrite", method = RequestMethod.GET)
	public String NoticeWrite() throws Exception {
		return "/notice/NoticeWrite";
	}
//TODO
	// 공지사항 글쓰기
	@RequestMapping(value = "/NoticeWrite", method = RequestMethod.POST)
	public String NoticeWrite(NoticeDTO dto, RedirectAttributes rttr) throws Exception {
//		String writer = (String) session.getAttribute("userID");
//		dto.setUserName(writer);
		int i = noticeService.NoticeWrite(dto);
		if (i > 0) {
			rttr.addFlashAttribute("result", dto.getBno());
			return "redirect:NoticeList";
		}
		return "/notice/NoriceWrite";
	}

	// 공지사항 상세보기
	@RequestMapping(value = "/NoticeDetail", method = RequestMethod.GET)
	public ModelAndView NoticeDetail(@RequestParam("bno") int bno, RedirectAttributes redirectModel, Model model, @ModelAttribute("searchPaging") SearchPaging searchPagign) throws Exception {
		ModelAndView mav = noticeService.NoticeDetail(bno , redirectModel);
		return mav;
	}

	// 공지사항 수정
	@RequestMapping(value = "/NoticeUpdate", method = RequestMethod.GET)
	public ModelAndView NoticeUpdate(@RequestParam("bno") int bno, RedirectAttributes redirectModel, Model model, @ModelAttribute("searchPaging") SearchPaging searchPagign)
			throws Exception {
		ModelAndView mav = noticeService.NoticeDetail2(bno, redirectModel);
		return mav;
	}

	// 공지사항 수정
	@RequestMapping(value = "/NoticeUpdate", method = RequestMethod.POST)
	public String NoticeUpdate(NoticeDTO dto, RedirectAttributes rttr, SearchPaging searchPaging) throws Exception {
		int i = noticeService.NoticeUpdate(dto);
		if (i > 0) {
			rttr.addFlashAttribute("result", "success");
//			 noticeService.NoticeUpdate(dto);
			 rttr.addAttribute("page", searchPaging.getPage());
			 rttr.addAttribute("perPageNum", searchPaging.getPerPageNum());
			 rttr.addAttribute("searchType", searchPaging.getSearchType());
			 rttr.addAttribute("keyword", searchPaging.getKeyword());
			 rttr.addFlashAttribute("msg", "modSuccess");
			return "redirect:NoticeList";
		}
		return "/notice/NoticeDetail";
	}

	// 공지사항 삭제
	@RequestMapping(value = "/NoticeDelete", method = RequestMethod.GET)
	public String NoticeDelete(@RequestParam("bno") int bno, RedirectAttributes rttr) throws Exception {
		int i = noticeService.NoticeDelete(bno);
		if (i > 0) {
			System.out.println("게시글이삭제되었습니다");
			return "redirect:NoticeList";
		}
		return "redirect:NoticeDetail?bno=" + bno;
	}

	//페이징처리
	@RequestMapping(value="/NoticePaging", method= RequestMethod.GET)
	public String NoticePaging(Model model, Paging paging) throws Exception{
		model.addAttribute("paging", noticeService.Paging(paging));
		return "/notice/NoticeList";
	}

}
