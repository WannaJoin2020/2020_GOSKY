CREATE TABLE `subject` (
  `sno` int NOT NULL AUTO_INCREMENT,
  `sname` varchar(10) NOT NULL,
  `startday` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `endday` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sday` varchar(10) DEFAULT NULL,
  `stime` varchar(10) DEFAULT NULL,
  `shour` varchar(10) DEFAULT NULL,
  `teacher` varchar(10) DEFAULT NULL,
  `content` varchar(10) DEFAULT NULL,
  `totalnum` int DEFAULT NULL,
  `nownum` int DEFAULT NULL,
  `room` int DEFAULT NULL,
  `limit` varchar(10) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`sno`),
  KEY `room` (`room`),
  CONSTRAINT `subject_room` FOREIGN KEY (`room`) REFERENCES `room` (`room`)
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;
