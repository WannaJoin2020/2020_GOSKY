package kr.co.gugu.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.co.gugu.dao.FreeBoardDAO;
import kr.co.gugu.domain.FreeBoardDTO;
import kr.co.gugu.domain.ReplyDTO;
import kr.co.gugu.domain.SearchPaging;

@Service
public class FreeBoardServiceImpl implements FreeBoardService {

	@Inject
	FreeBoardDAO FreeBoardDAO;

	@Override
	public List<FreeBoardDTO> FreeBoardList() throws Exception {
		
		return FreeBoardDAO.FreeBoardList();
	}

	@Override
	public int FreeBoardWrite(FreeBoardDTO dto) throws Exception {
		return FreeBoardDAO.FreeBoardWrite(dto);
	}

	@Override
	public ModelAndView FreeBoardDetail(int bno, RedirectAttributes redirectModel) throws Exception {
		int count = FreeBoardDAO.FreeBoardExist(bno);
		if(count==0) {
			ModelAndView mav = new ModelAndView();
			mav.setViewName("redirect:FreeBoardList");
			redirectModel.addFlashAttribute("exist", "해당 게시물은 삭제되었거나 존재하지 않습니다" );
		}
		ModelAndView mav = new ModelAndView();
		FreeBoardDAO.ReadCnt(bno);
		mav.addObject("FreeBoard", FreeBoardDAO.FreeBoardDetail(bno)); 
		mav.setViewName("/freeboard/FreeBoardDetail");
		return mav;
	}

	@Override
	public ModelAndView FreeBoardDetail2(int bno, RedirectAttributes redirectModel) throws Exception {
		int count = FreeBoardDAO.FreeBoardExist(bno);
		if(count==0) {
			ModelAndView mav = new ModelAndView();
			mav.setViewName("redirect:FreeBoardList");
			redirectModel.addFlashAttribute("exist", "해당 게시물은 삭제되었거나 존재하지 않습니다" );
		}
		ModelAndView mav = new ModelAndView();
		mav.addObject("FreeBoard", FreeBoardDAO.FreeBoardDetail(bno)); 
		mav.setViewName("/freeboard/FreeBoardUpdate");
		return mav;
	}
	@Override
	public int FreeBoardUpdate(FreeBoardDTO dto) throws Exception {
		return FreeBoardDAO.FreeBoardUpdate(dto);
	}

	@Override
	public int FreeBoardDelete(int bno) throws Exception {
		
		return FreeBoardDAO.FreeBoardDelete(bno);
	}

	@Override
	public List<FreeBoardDTO> Paging(kr.co.gugu.domain.Paging paging) throws Exception {
		return FreeBoardDAO.Paging(paging);
	}

	@Override
	public int CountPaging(kr.co.gugu.domain.Paging paging) throws Exception {
		return FreeBoardDAO.CountPaging(paging);
	}

	@Override
	public List<FreeBoardDTO> Search(SearchPaging searchPaging) throws Exception {
		return FreeBoardDAO.Search(searchPaging);
	}

	@Override
	public int CountSearch(SearchPaging searchPaging) throws Exception {
		return FreeBoardDAO.CountSearch(searchPaging);
	}
	@Override
	public List<ReplyDTO> ReplyList(int rno) throws Exception {
		return FreeBoardDAO.ReplyList(rno);
	}

	@Override
	public int ReplyWrite(ReplyDTO replyDTO) throws Exception {
		return FreeBoardDAO.ReplyWrite(replyDTO);

	}

	@Override
	public int ReplyUpdate(ReplyDTO replyDTO) throws Exception {
		return FreeBoardDAO.ReplyUpdate(replyDTO);

	}

	@Override
	public int ReplyDelete(int rno) throws Exception {
		return FreeBoardDAO.ReplyDelete(rno);

	}
}
