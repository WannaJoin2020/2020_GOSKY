package kr.co.gugu.service;

import java.util.List;

import kr.co.gugu.domain.PeopleDTO;
import kr.co.gugu.domain.MemberDTO;
import kr.co.gugu.domain.Paging;
import kr.co.gugu.domain.SearchPaging;

public interface StudentService {

	// 원생추가
	public int signup(MemberDTO member);
	
	// 원생리스트 + 검색처리
	public List<MemberDTO> MemberSearch() throws Exception;

	//nav 마이페이지 상세보기
	public MemberDTO MemberDetail(int mno) throws Exception;
	
	//마이페이지 상세보기_ 아이디로 검색
	public MemberDTO MemberSearchId(String mid) throws Exception;
	
	//클라이언트 상세보기_ 아이디로 검색
	public List<PeopleDTO> PeopleSearchId(String mid)throws Exception;

	//nav 정보수정
	public int MemberInfoUpdate(MemberDTO memberDTO)throws Exception;
	
	//마이페이지 정보수정
	public int MemberMypageUpdate(MemberDTO memberDTO);
	
	//마이페이지 정보수정
	public int PeopleMypageUpdate(PeopleDTO peopleDTO);
	
	//원생삭제
	public int MemberDelete(int mno) throws Exception;
	
	//원생추가
	public int PeopleAdd(PeopleDTO peopleDTO) throws Exception;
	
	//페이징처리
	public List<MemberDTO> Paging(Paging paging) throws Exception;
	
	//페이징처리 _전체게시글 갯수 구하기
	public int CountPaging(Paging paging) throws Exception;
	
	//검색목록
	public List<MemberDTO> Search(SearchPaging searchPaging) throws Exception;
	
	//검색된 게시글 갯수구하기
	public int CountSearch(SearchPaging searchPaging) throws Exception;

}
