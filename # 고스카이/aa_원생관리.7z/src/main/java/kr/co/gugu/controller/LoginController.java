package kr.co.gugu.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import kr.co.gugu.common.SnsLoginAPI;
import kr.co.gugu.domain.MemberDTO;
import kr.co.gugu.service.MemberService;

@Controller
public class LoginController {

	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	MemberService memberService;
	
	@RequestMapping(value = "/login/form", method = RequestMethod.GET)
	public String loginForm() {
		logger.info("login - form");
		return "member/login";
	}
	
	@ResponseBody
	@RequestMapping(value = "/login/checkIdAndPassword", method = RequestMethod.POST)
	public boolean checkIdAndPassword(@RequestParam Map<String, String> map, HttpSession session) {
		logger.info("login - id and pw check");
		return (memberService.checkIdAndPassword(map, session) == 1);
	}
	
	@RequestMapping(value = "/login/action", method = RequestMethod.POST)
	public String login(@ModelAttribute MemberDTO member, HttpSession session) {
		logger.info("login - action");
		memberService.login(member, session);
		return "redirect:/";
	}
	
	@RequestMapping(value = "/signup/form", method = RequestMethod.GET)
	public String signupForm() {
		logger.info("signup - form");
		return "member/signup";
	}
	
	@ResponseBody
	@RequestMapping(value = "/signup/duplicateCheck", method = RequestMethod.GET)
	public boolean duplicateCheckId(@RequestParam Map<String, String> map) {
		return (memberService.duplicateCheck(map) == 0);
	}
	
	@RequestMapping(value = "/signup/addMember", method = RequestMethod.POST)
	public String addMember(@ModelAttribute MemberDTO member) {
		logger.info("signup - addMember");
		memberService.signup(member);
		return "redirect:/login/form";
	}
	
	@RequestMapping(value = "/logout")
	public String addMember(HttpSession session) {
		logger.info("logout");
		memberService.logout(session);
		return "redirect:/login/form";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Autowired
	SnsLoginAPI loginApi;
	
	@ResponseBody
	@RequestMapping(value="/login/getUrl")
	public Map<String, String> getUrl(@RequestParam Map<String, String> map) {
		return loginApi.getURL(map);
	}
	
	@RequestMapping(value="/login/forKakao")
	public String loginForKakao(@RequestParam("code") String code, HttpSession session) {
		String access_Token = loginApi.getAccessToken(code, "kakao");
        String id = loginApi.getUserInfo(access_Token, "kakao");
        

        memberService.loginForSNS(id, session);
        
        return "redirect: ../";
	}
	
	@RequestMapping(value="/login/forGoogle")
	public String loginForGoogle(@RequestParam("code") String code, HttpSession session) {
		String access_Token = loginApi.getAccessToken(code, "google");
		String id = loginApi.getUserInfo(access_Token, "google");
		
		memberService.loginForSNS(id, session);
		
		return "redirect: ../";
	}
	
	@RequestMapping(value="/login/forNaver")
	public String loginForNaver(@RequestParam("code") String code, HttpSession session) {
		String access_Token = loginApi.getAccessToken(code, "naver");
		String id = loginApi.getUserInfo(access_Token, "naver");
		
		memberService.loginForSNS(id, session);
		
		return "redirect: ../";
	}
	
}
