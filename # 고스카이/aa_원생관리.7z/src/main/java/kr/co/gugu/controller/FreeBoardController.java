package kr.co.gugu.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.co.gugu.common.LoggerAspect;
import kr.co.gugu.domain.MemberDTO;
import kr.co.gugu.domain.FreeBoardDTO;
import kr.co.gugu.domain.PageMaker;
import kr.co.gugu.domain.Paging;
import kr.co.gugu.domain.ReplyDTO;
import kr.co.gugu.domain.SearchPaging;
import kr.co.gugu.service.FreeBoardService;
import kr.co.gugu.dao.MemberDAO;
import kr.co.gugu.dao.FreeBoardDAO;

@Controller
public class FreeBoardController {

	@Inject
	FreeBoardService FreeBoardService;
	FreeBoardDAO FreeBoardDAO;
	MemberDAO memberDAO;

	protected Logger log = LoggerFactory.getLogger(LoggerAspect.class);

	//목륵, 검색처리
	@RequestMapping(value = "/FreeBoardList", method = RequestMethod.GET)
    public String FreeBoardSearch(@ModelAttribute("searchPaging") SearchPaging searchPaging,
                       Model model) throws Exception {

        PageMaker pageMaker = new PageMaker();
        pageMaker.setPaging(searchPaging);
        pageMaker.setTotalCount(FreeBoardService.CountSearch(searchPaging));

        model.addAttribute("list", FreeBoardService.Search(searchPaging));
        model.addAttribute("pageMaker", pageMaker);

		return "/freeboard/FreeBoardList";
    }
	
	// 자유게시판 글쓰기
	@RequestMapping(value = "/FreeBoardWrite", method = RequestMethod.GET)
	public String FreeBoardWrite() throws Exception {
		return "/freeboard/FreeBoardWrite";
	}

	// 자유게시판 글쓰기
	@RequestMapping(value = "/FreeBoardWrite", method = RequestMethod.POST)
	public String FreeBoardWrite(FreeBoardDTO dto, RedirectAttributes rttr) throws Exception {
//		String writer = (String) session.getAttribute("userID");
//		dto.setUserName(writer);
		int i = FreeBoardService.FreeBoardWrite(dto);
		if (i > 0) {
			rttr.addFlashAttribute("result", dto.getBno());
			return "redirect:FreeBoardList";
		}
		return "/freeboard/FreeBoardWrite";
	}
	// 자유게시판 상세보기
	@RequestMapping(value = "/FreeBoardDetail", method = RequestMethod.GET)
	public ModelAndView FreeBoardDetail(@RequestParam("bno") int bno, RedirectAttributes redirectModel, Model model, @ModelAttribute("searchPaging") SearchPaging searchPagign) throws Exception {
		ModelAndView mav = FreeBoardService.FreeBoardDetail(bno , redirectModel);
		return mav;
	}

	// 자유게시판 수정
	@RequestMapping(value = "/FreeBoardUpdate", method = RequestMethod.GET)
	public ModelAndView FreeBoardUpdate(@RequestParam("bno") int bno, RedirectAttributes redirectModel, Model model, @ModelAttribute("searchPaging") SearchPaging searchPagign)
			throws Exception {
		ModelAndView mav = FreeBoardService.FreeBoardDetail2(bno, redirectModel);
		return mav;
	}

	// 자유게시판 수정
	@RequestMapping(value = "/FreeBoardUpdate", method = RequestMethod.POST)
	public String FreeBoardUpdate(FreeBoardDTO dto, RedirectAttributes rttr, SearchPaging searchPaging) throws Exception {
		int i = FreeBoardService.FreeBoardUpdate(dto);
		if (i > 0) {
			rttr.addFlashAttribute("result", "success");
//			 FreeBoardService.FreeBoardUpdate(dto);
			 rttr.addAttribute("page", searchPaging.getPage());
			 rttr.addAttribute("perPageNum", searchPaging.getPerPageNum());
			 rttr.addAttribute("searchType", searchPaging.getSearchType());
			 rttr.addAttribute("keyword", searchPaging.getKeyword());
			 rttr.addFlashAttribute("msg", "modSuccess");
			return "redirect:FreeBoardList";
		}
		return "/freeboard/FreeBoardDetail";
	}

	// 자유게시판 삭제
	@RequestMapping(value = "/FreeBoardDelete", method = RequestMethod.GET)
	public String FreeBoardDelete(@RequestParam("bno") int bno, RedirectAttributes rttr) throws Exception {
		int i = FreeBoardService.FreeBoardDelete(bno);
		if (i > 0) {
			System.out.println("게시글이삭제되었습니다");
			return "redirect:FreeBoardList";
		}
		return "redirect:FreeBoardDetail?bno=" + bno;
	}

	//페이징처리
	@RequestMapping(value="/FreeBoardPaging", method= RequestMethod.GET)
	public String FreeBoardPaging(Model model, Paging paging) throws Exception{
		model.addAttribute("paging", FreeBoardService.Paging(paging));
		return "/freeboard/FreeBoardList";
	}
	
//	===============================Ajax 댓글===============================
	//TODO
	// 댓글 목록
		@ResponseBody
		@RequestMapping(value = "/ReplyList", method = RequestMethod.POST)
		public List<ReplyDTO> ReplyList(@RequestParam("bno") int bno) throws Exception {
			    return FreeBoardService.ReplyList(bno);
			}

		// 댓글작성
		@ResponseBody
		@RequestMapping(value = "/ReplyWrite", method = RequestMethod.POST)
		public Map<String , Object> ReplyWrite(ReplyDTO replyDTO) {
			Map<String , Object> result = new HashMap<String, Object>();		
			try{
				FreeBoardService.ReplyWrite(replyDTO);  // 추가
				result.put("status", "OK");
			}
			catch(Exception e) {
				e.printStackTrace();
				result.put("status", "Fail");
			}
			return result;
		}
		
		// 댓글수정
		@ResponseBody
		@RequestMapping(value = "/ReplyUpdate", method = RequestMethod.POST)
			public Map<String, Object> ReplyUpdate(ReplyDTO replyDTO) throws Exception {
				Map<String, Object> result = new HashMap<String, Object>();
				try {
					FreeBoardService.ReplyUpdate(replyDTO); // 수정 또는 삭제
					result.put("status", "ok");
				} catch (Exception e) {
					e.printStackTrace();
					result.put("status", "fail");
				}
				return result;
			}

		// 댓글삭제
		@ResponseBody
		@RequestMapping(value = "/ReplyDelete", method = RequestMethod.POST)
			public Map<String, Object> ReplyDelete(@RequestParam("rno") int rno) throws Exception {
				Map<String, Object> result = new HashMap<String, Object>();
				try {
					FreeBoardService.ReplyDelete(rno); // 수정 또는 삭제
					result.put("status", "ok");
				} catch (Exception e) {
					e.printStackTrace();
					result.put("status", "fail");
				}
				return result;
			}
}
