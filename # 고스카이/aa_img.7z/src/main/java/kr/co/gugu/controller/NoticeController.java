package kr.co.gugu.controller;

import java.io.File;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.co.gugu.common.LoggerAspect;
import kr.co.gugu.domain.NoticeDTO;
import kr.co.gugu.domain.PageMaker;
import kr.co.gugu.domain.Paging;
import kr.co.gugu.domain.SearchPaging;
import kr.co.gugu.service.NoticeService;
import kr.co.gugu.util.UploadFile;
import kr.co.gugu.dao.MemberDAO;
import kr.co.gugu.dao.NoticeDAO;

@Controller
public class NoticeController {

	@Inject
	NoticeService noticeService;
	NoticeDAO noticeDAO;
	MemberDAO memberDAO;

	protected Logger log = LoggerFactory.getLogger(LoggerAspect.class);
	private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);

	//목록, 검색처리
	@RequestMapping(value = "/NoticeList", method = RequestMethod.GET)
    public String NoticeSearch(@ModelAttribute("searchPaging") SearchPaging searchPaging,
                       Model model) throws Exception {

        PageMaker pageMaker = new PageMaker();
        pageMaker.setPaging(searchPaging);
        pageMaker.setTotalCount(noticeService.CountSearch(searchPaging));

        model.addAttribute("list", noticeService.Search(searchPaging));
        model.addAttribute("pageMaker", pageMaker);

		return "/notice/NoticeList";
    }

	
//TODO
	@Resource(name = "uploadPath")
	private String uploadPath;
	
	// 공지사항 글쓰기
	@RequestMapping(value = "/NoticeWrite", method = RequestMethod.GET)
	public String NoticeWrite() throws Exception {
		return "/notice/NoticeWrite";
	}
	
	// 공지사항 글쓰기
	@RequestMapping(value = "/NoticeWrite", method = RequestMethod.POST)
	public String NoticeWrite(NoticeDTO dto, RedirectAttributes rttr, MultipartFile file) throws Exception {
		
		String imgUploadPath = uploadPath + File.separator + "imgUpload";
		String ymdPath = UploadFile.calcPath(imgUploadPath);
		String fileName = null;

		if(file != null) {
		 fileName =UploadFile.fileUpload(imgUploadPath, file.getOriginalFilename(), file.getBytes(), ymdPath); 
		} else {
		 fileName = uploadPath + File.separator + "images" + File.separator + "none.png";
		}

		dto.setSupload(File.separator + "imgUpload" + ymdPath + File.separator + "s" + File.separator + "s_" + fileName);
		
		noticeService.NoticeWrite(dto);
			return "redirect:NoticeList";
	}

	// 공지사항 상세보기
	@RequestMapping(value = "/NoticeDetail", method = RequestMethod.GET)
	public ModelAndView NoticeDetail(@RequestParam("bno") int bno, RedirectAttributes redirectModel, Model model, @ModelAttribute("searchPaging") SearchPaging searchPagign) throws Exception {
		ModelAndView mav = noticeService.NoticeDetail(bno , redirectModel);
		return mav;
	}

	// 공지사항 수정
	@RequestMapping(value = "/NoticeUpdate", method = RequestMethod.GET)
	public ModelAndView NoticeUpdate(@RequestParam("bno") int bno, RedirectAttributes redirectModel)
			throws Exception {
		ModelAndView mav = noticeService.NoticeDetail2(bno, redirectModel);
		return mav;
	}

	// 공지사항 수정
	@RequestMapping(value = "/NoticeUpdate", method = RequestMethod.POST)
	public String NoticeUpdate(NoticeDTO dto,   MultipartFile file, HttpServletRequest req, @RequestParam("bno") int bno) throws Exception {
		// 새로운 파일이 등록되었는지 확인
		 if(file.getOriginalFilename() != null && file.getOriginalFilename() != "") {
		  // 기존 파일을 삭제
		  new File(uploadPath + req.getParameter("supload")).delete();
		  
		  // 새로 첨부한 파일을 등록
		  String imgUploadPath = uploadPath + File.separator + "imgUpload";
		  String ymdPath = UploadFile.calcPath(imgUploadPath);
		  String fileName = UploadFile.fileUpload(imgUploadPath, file.getOriginalFilename(), file.getBytes(), ymdPath);
		  
		  dto.setSupload(File.separator + "imgUpload" + ymdPath + File.separator + "s" + File.separator + "s_" + fileName);
		  
		 } else {  // 새로운 파일이 등록되지 않았다면
		  // 기존 이미지를 그대로 사용
			 dto.setSupload(req.getParameter("supload"));
		 }
		 
		noticeService.NoticeUpdate(dto);
			return "redirect:NoticeList";
		}

	// 공지사항 삭제
	@RequestMapping(value = "/NoticeDelete", method = RequestMethod.GET)
	public String NoticeDelete(@RequestParam("bno") int bno, RedirectAttributes rttr) throws Exception {
		int i = noticeService.NoticeDelete(bno);
		if (i > 0) {
			System.out.println("게시글이삭제되었습니다");
			return "redirect:NoticeList";
		}
		return "redirect:NoticeDetail?bno=" + bno;
	}

	//페이징처리
	@RequestMapping(value="/NoticePaging", method= RequestMethod.GET)
	public String NoticePaging(Model model, Paging paging) throws Exception{
		model.addAttribute("paging", noticeService.Paging(paging));
		return "/notice/NoticeList";
	}

}
