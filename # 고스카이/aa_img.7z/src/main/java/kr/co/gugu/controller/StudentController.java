package kr.co.gugu.controller;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import kr.co.gugu.dao.StudentDAO;
import kr.co.gugu.domain.MemberDTO;
import kr.co.gugu.domain.PageMaker;
import kr.co.gugu.domain.Paging;
import kr.co.gugu.domain.PeopleDTO;
import kr.co.gugu.domain.SearchPaging;
import kr.co.gugu.service.StudentService;

@Controller
public class StudentController {

	@Inject
	StudentService studentService;
	StudentDAO studentDAO;

	// 원생등록 ------> http://localhost:8080/gugu/signup/form
	@RequestMapping(value = "/MemberAdd", method = RequestMethod.GET)
	public String MemberAdd() {
		return "member/signup";
	}

	// 원생검색
	@RequestMapping(value = "/MemberSearch", method = RequestMethod.GET)
	public String MemberSearch(Model model, @ModelAttribute("searchPaging") SearchPaging searchPaging)
			throws Exception {

		PageMaker pageMaker = new PageMaker();
		pageMaker.setPaging(searchPaging);
		pageMaker.setTotalCount(studentService.CountSearch(searchPaging));

		model.addAttribute("MemberList", studentService.Search(searchPaging));
		model.addAttribute("pageMaker", pageMaker);

//		model.addAttribute("MemberList", studentService.MemberSearch());
		return "/student/MemberSearch";
	}

	// 페이징처리
	@RequestMapping(value = "/MemberPaging", method = RequestMethod.GET)
	public String MemberPaging(Model model, Paging paging) throws Exception {
		model.addAttribute("paging", studentService.Paging(paging));
		return "/student/MemberSearch";
	}

//	// 원생정보보기
//	@RequestMapping(value = "/MemberDetail", method = RequestMethod.GET)
//	public ModelAndView MemberDetail(@RequestParam("mno") int mno, @RequestParam("mid") String mid) throws Exception {
//		ModelAndView mav = new ModelAndView();
//		mav.addObject("member",studentService.MemberDetail(mno));
//		mav.addObject("people",studentService.PeopleSearchId(mid));
//		mav.setViewName("/student/MemberDetail");
//		return mav;
//	}
//	
//	// 원생정보수정
//	@RequestMapping(value = "/MemberInfoUpdate", method = RequestMethod.GET)
//	public ModelAndView MemberInfoUpdate(@RequestParam("mno") int mno) throws Exception {
//		ModelAndView mav = new ModelAndView();
//		mav.addObject("member",studentService.MemberDetail(mno));
//		mav.setViewName("/student/MemberInfoUpdate");
//		return mav;
//	}
//	
//	@RequestMapping(value = "/MemberInfoUpdate", method = RequestMethod.POST)
//	public String MemberInfoUpdate (MemberDTO memberDTO) throws Exception {
//		int r = studentService.MemberInfoUpdate(memberDTO);
//		if(r>0) {
//			return "redirect:MemberSearch";
//			}
//		return "/student/MemberDetail";
//	}

	// 마이페이지정보수정
	@RequestMapping(value = "/MemberMypageUpdate", method = RequestMethod.GET)
	public ModelAndView MemberMypageUpdate(@RequestParam("mid") String mid) throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.addObject("member", studentService.MemberSearchId(mid));
		mav.addObject("people", studentService.PeopleSearchId(mid));
		mav.setViewName("/student/MemberMypageUpdate");
		return mav;
	}
	
	@RequestMapping(value = "/MemberMypageUpdate", method = RequestMethod.POST)
	public String MemberMypageUpdate(MemberDTO memberDTO) throws Exception {
		int r = studentService.MemberMypageUpdate(memberDTO);
		if (r > 0) {
			return "redirect:MemberSearch";
		}
		return "/student/MemberMypageUpdate";
	}


	@RequestMapping(value = "/PeopleMypageUpdate", method = RequestMethod.POST)
	public String PeopleMypageUpdate(PeopleDTO peopleDTO, @RequestParam("pno") int pno) throws Exception {
		int r = studentService.PeopleMypageUpdate(peopleDTO);
		if (r > 0) {
			return "redirect:MemberSearch";
		}
		return "/student/MemberMypageUpdate";
	}

	// 원생추가
	@RequestMapping(value = "/PeopleAdd", method = RequestMethod.GET)
	public String PeopleAdd() throws Exception {
		return "/student/PeopleAdd";
	}

	@RequestMapping(value = "/PeopleAdd", method = RequestMethod.POST)
	public String PeopleAdd(PeopleDTO peopleDTO) throws Exception {
		studentService.PeopleAdd(peopleDTO);
		return "redirect:MemberSearch";
	}

//	// 원생삭제
//	@RequestMapping(value = "/MemberDelete", method = RequestMethod.GET)
//	public String MemberDelete(@RequestParam("mno") int mno) throws Exception {
//		int r = studentService.MemberDelete(mno);
//		if(r>0) {
//			return "redirect:MemberSearch";
//		}
//		return "/student/MemberDetail";
//	}

}
