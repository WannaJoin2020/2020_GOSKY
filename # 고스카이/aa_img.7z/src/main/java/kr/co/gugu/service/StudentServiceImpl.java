package kr.co.gugu.service;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.co.gugu.dao.StudentDAO;
import kr.co.gugu.domain.PeopleDTO;
import kr.co.gugu.domain.InterviewDTO;
import kr.co.gugu.domain.MemberDTO;
import kr.co.gugu.domain.SearchPaging;

@Service
public class StudentServiceImpl implements StudentService {

	@Inject
	StudentDAO StudentDAO;

	//원생추가
//	@Override
//	public int signup(MemberDTO memberDTO) {
//		return StudentDAO.addMember(memberDTO);
//	}
	// 원생리스트 + 검색처리
	@Override
	public List<MemberDTO> MemberSearch() throws Exception {
		return StudentDAO.MemberSearch();
	}
	
//	//nav 마이페이지 상세보기
//	@Override
//	public MemberDTO MemberDetail(int mno) throws Exception {
//		return StudentDAO.MemberDetail(mno);
//	}
	
	//마이페이지 상세보기_ 아이디로 검색
	@Override
	public MemberDTO MemberSearchId(String mid) throws Exception {
		return StudentDAO.MemberSearchId(mid);
	}
	
	//클라이언트 상세보기_ 아이디로 검색
	@Override
	public List<PeopleDTO> PeopleSearchId(String mid) throws Exception {
		return StudentDAO.PeopleSearchId(mid);
	}
	
//	//nav 정보수정
//	@Override
//	public int MemberInfoUpdate(MemberDTO memberDTO) throws Exception {
//		return StudentDAO.MemberInfoUpdate(memberDTO);
//	}

	//마이페이지 정보수정
	@Override
	public int MemberMypageUpdate(MemberDTO memberDTO) {
		return StudentDAO.MemberMypageUpdate(memberDTO);
	}
	
	//마이페이지 정보수정
	@Override
	public int PeopleMypageUpdate(PeopleDTO peopleDTO) {
		return StudentDAO.PeopleMypageUpdate(peopleDTO);
	}
	
//	//원생삭제
//	@Override
//	public int MemberDelete(int mno) throws Exception {
//		return StudentDAO.MemberDelete(mno);
//	}
	
	//원생추가
	@Override
	public int PeopleAdd(PeopleDTO peopleDTO) throws Exception {
		return StudentDAO.PeopleAdd(peopleDTO);
	}
	
	@Override
	public List<MemberDTO> Paging(kr.co.gugu.domain.Paging paging) throws Exception {
		return StudentDAO.Paging(paging);
	}

	@Override
	public int CountPaging(kr.co.gugu.domain.Paging paging) throws Exception {
		return StudentDAO.CountPaging(paging);
	}

	@Override
	public List<MemberDTO> Search(SearchPaging searchPaging) throws Exception {
		return StudentDAO.Search(searchPaging);
		
	}

	@Override
	public int CountSearch(SearchPaging searchPaging) throws Exception {
		return StudentDAO.CountSearch(searchPaging);
	}




}
