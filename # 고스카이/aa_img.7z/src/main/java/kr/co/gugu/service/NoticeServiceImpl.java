package kr.co.gugu.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.co.gugu.dao.NoticeDAO;
import kr.co.gugu.domain.NoticeDTO;
import kr.co.gugu.domain.SearchPaging;

@Service
public class NoticeServiceImpl implements NoticeService {

	@Inject
	NoticeDAO noticeDAO;

	@Override
	public List<NoticeDTO> NoticeList() throws Exception {
		
		return noticeDAO.NoticeList();
	}

	@Override
	public int NoticeWrite(NoticeDTO dto) throws Exception {
		return noticeDAO.NoticeWrite(dto);
	}

	@Override
	public ModelAndView NoticeDetail(int bno, RedirectAttributes redirectModel) throws Exception {
		int count = noticeDAO.NoticeExist(bno);
		if(count==0) {
			ModelAndView mav = new ModelAndView();
			mav.setViewName("redirect:NoticeList");
			redirectModel.addFlashAttribute("exist", "해당 게시물은 삭제되었거나 존재하지 않습니다" );
		}
		ModelAndView mav = new ModelAndView();
		noticeDAO.ReadCnt(bno);
		mav.addObject("notice", noticeDAO.NoticeDetail(bno)); 
		mav.setViewName("/notice/NoticeDetail");
		return mav;
	}

	@Override
	public ModelAndView NoticeDetail2(int bno, RedirectAttributes redirectModel) throws Exception {
		int count = noticeDAO.NoticeExist(bno);
		if(count==0) {
			ModelAndView mav = new ModelAndView();
			mav.setViewName("redirect:NoticeList");
			redirectModel.addFlashAttribute("exist", "해당 게시물은 삭제되었거나 존재하지 않습니다" );
		}
		ModelAndView mav = new ModelAndView();
		mav.addObject("notice", noticeDAO.NoticeDetail(bno)); 
		mav.setViewName("/notice/NoticeUpdate");
		return mav;
	}
	@Override
	public int NoticeUpdate(NoticeDTO dto) throws Exception {
		return noticeDAO.NoticeUpdate(dto);
	}

	@Override
	public int NoticeDelete(int bno) throws Exception {
		
		return noticeDAO.NoticeDelete(bno);
	}

	@Override
	public List<NoticeDTO> Paging(kr.co.gugu.domain.Paging paging) throws Exception {
		return noticeDAO.Paging(paging);
	}

	@Override
	public int CountPaging(kr.co.gugu.domain.Paging paging) throws Exception {
		return noticeDAO.CountPaging(paging);
	}

	@Override
	public List<NoticeDTO> Search(SearchPaging searchPaging) throws Exception {
		return noticeDAO.Search(searchPaging);
	}

	@Override
	public int CountSearch(SearchPaging searchPaging) throws Exception {
		return noticeDAO.CountSearch(searchPaging);
	}
}
