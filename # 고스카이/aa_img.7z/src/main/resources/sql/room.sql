CREATE TABLE `room` (
  `room` int NOT NULL AUTO_INCREMENT,
  `roomdater` varchar(10) NOT NULL,
  `rmanager` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`room`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
