package kr.co.gugu.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import kr.co.gugu.domain.NoticeDTO;
import kr.co.gugu.domain.Paging;
import kr.co.gugu.domain.SearchPaging;

@Repository
public class NoticeDAOImpl implements NoticeDAO {

	@Inject
	SqlSession sqlSession;

	private String namespace = "mappers.NoticeMapper";

	@Override
	public List<NoticeDTO> NoticeList() throws Exception {
		return sqlSession.selectList(namespace+".NoticeList");
	}

	@Override
	public int NoticeWrite(NoticeDTO dto) throws Exception {
		return sqlSession.insert(namespace+".NoticeWrite", dto);
	}

	
	@Override
	public NoticeDTO NoticeDetail(int bno) throws Exception {
		return sqlSession.selectOne(namespace+".NoticeDetail", bno);
	}

	@Override
	public int NoticeUpdate(NoticeDTO dto) throws Exception {
		return sqlSession.update(namespace+".NoticeUpdate", dto);
	}

	@Override
	public int NoticeDelete(int bno) throws Exception {
		return sqlSession.delete(namespace+".NoticeDelete", bno);
	}

	@Override
	public int NoticeExist(int bno) throws Exception {
		return sqlSession.selectOne(namespace+".NoticeExist", bno);
	}

	@Override
	public int ReadCnt(int bno) throws Exception {
		return sqlSession.update(namespace+".NoticeReadCnt", bno);
	}

	@Override
	public List<NoticeDTO> Paging(Paging paging) throws Exception {
		return sqlSession.selectList(namespace+".Paging", paging);
	}

	@Override
	public int CountPaging(Paging paging) throws Exception {
		return sqlSession.selectOne(namespace+".CountPaging",paging);
	}

	@Override
	public List<NoticeDTO> Search(SearchPaging searchPaging) throws Exception {
		return sqlSession.selectList(namespace+".Search", searchPaging);
	}

	@Override
	public int CountSearch(SearchPaging searchPaging) throws Exception {
		return sqlSession.selectOne(namespace+".SearchPaging",searchPaging);
	}

}
