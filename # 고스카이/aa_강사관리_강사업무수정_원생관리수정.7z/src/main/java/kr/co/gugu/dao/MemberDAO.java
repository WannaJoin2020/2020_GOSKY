package kr.co.gugu.dao;

import java.util.Map;

import kr.co.gugu.domain.MemberDTO;

public interface MemberDAO {

	// 회원 가입
		// 아이디 중복 체크
		public int checkDuplicatedId(String mid);
	
		// 이메일 중복 체크
		public int checkDuplicatedEmail(String memail);
	
		// 회원 추가
		public int addMember(MemberDTO dto);
		
		// 회원 추가 - SNS
		public int addMemberSNS(MemberDTO dto);
		
		// 회원 정보 가져오기 - 테스트 용
		public MemberDTO getUserInfo(String id);
		
		// ID 비밀번호 체크
		public int checkIdAndPassword(Map<String, String> map);
	
}
