package kr.co.gugu.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import kr.co.gugu.domain.FreeBoardDTO;
import kr.co.gugu.domain.Paging;
import kr.co.gugu.domain.ReplyDTO;
import kr.co.gugu.domain.SearchPaging;

@Repository
public class FreeBoardDAOImpl implements FreeBoardDAO {

	@Inject
	SqlSession sqlSession;

	private String namespace = "mappers.FreeBoardMapper";

	@Override
	public List<FreeBoardDTO> FreeBoardList() throws Exception {
		return sqlSession.selectList(namespace+".FreeBoardList");
	}

	@Override
	public int FreeBoardWrite(FreeBoardDTO dto) throws Exception {
		return sqlSession.insert(namespace+".FreeBoardWrite", dto);
	}

	
	@Override
	public FreeBoardDTO FreeBoardDetail(int bno) throws Exception {
		return sqlSession.selectOne(namespace+".FreeBoardDetail", bno);
	}

	@Override
	public int FreeBoardUpdate(FreeBoardDTO dto) throws Exception {
		return sqlSession.update(namespace+".FreeBoardUpdate", dto);
	}

	@Override
	public int FreeBoardDelete(int bno) throws Exception {
		return sqlSession.delete(namespace+".FreeBoardDelete", bno);
	}

	@Override
	public int FreeBoardExist(int bno) throws Exception {
		return sqlSession.selectOne(namespace+".FreeBoardExist", bno);
	}

	@Override
	public int ReadCnt(int bno) throws Exception {
		return sqlSession.update(namespace+".FreeBoardReadCnt", bno);
	}

	@Override
	public List<FreeBoardDTO> Paging(Paging paging) throws Exception {
		return sqlSession.selectList(namespace+".Paging", paging);
	}

	@Override
	public int CountPaging(Paging paging) throws Exception {
		return sqlSession.selectOne(namespace+".CountPaging",paging);
	}

	@Override
	public List<FreeBoardDTO> Search(SearchPaging searchPaging) throws Exception {
		return sqlSession.selectList(namespace+".Search", searchPaging);
	}

	@Override
	public int CountSearch(SearchPaging searchPaging) throws Exception {
		return sqlSession.selectOne(namespace+".SearchPaging",searchPaging);
	}


	@Override
	public List<ReplyDTO> ReplyList(int rno) throws Exception {
		return sqlSession.selectList(namespace+".ReplyList",rno);
	}

	@Override
	public int ReplyWrite(ReplyDTO replyDTO) throws Exception {
		return sqlSession.insert(namespace+".ReplyWrite" , replyDTO);
	}

	@Override
	public int ReplyUpdate(ReplyDTO replyDTO) throws Exception {
		return sqlSession.update(namespace+".ReplyUpdate", replyDTO);

	}

	@Override
	public int ReplyDelete(int rno) throws Exception {
		return sqlSession.update(namespace+".ReplyDelete", rno);

	}
}
