package kr.co.gugu.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import kr.co.gugu.domain.MemberDTO;

public interface MemberService {

	// SNS 로그인
	public String loginForSNS(String id, HttpSession session);
	
	// 회원 가입
	public int signup(MemberDTO member);
	
	// 중복 체크 ID or Email
	public int duplicateCheck(Map<String, String> map);
	
	// ID 비밀번호 확인
	public int checkIdAndPassword(Map<String, String> map, HttpSession session);
	
	// 로그인
	public String login(MemberDTO member, HttpSession session);
	
	// 로그아웃
	public String logout(HttpSession session);
		
	
}
