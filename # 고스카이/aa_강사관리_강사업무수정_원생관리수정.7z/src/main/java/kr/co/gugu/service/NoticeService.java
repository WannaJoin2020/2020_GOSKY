package kr.co.gugu.service;

import java.util.List;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.co.gugu.dao.NoticeDAO;
import kr.co.gugu.domain.NoticeDTO;
import kr.co.gugu.domain.Paging;
import kr.co.gugu.domain.SearchPaging;

public interface NoticeService {

	// 게시글목록
	public List<NoticeDTO> NoticeList() throws Exception;

	// 게시글작성
	public int NoticeWrite(NoticeDTO dto) throws Exception;

	// 게시글보기
	public ModelAndView NoticeDetail(int bno, RedirectAttributes redirectModel) throws Exception;
	public ModelAndView NoticeDetail2(int bno, RedirectAttributes redirectModel) throws Exception;
	
	// 게시글수정
	public int NoticeUpdate(NoticeDTO dto) throws Exception;

	// 게시글삭제
	public int NoticeDelete(int bno) throws Exception;

	//페이징처리
	public List<NoticeDTO> Paging(Paging paging) throws Exception;
	
	//페이징처리 _전체게시글 갯수 구하기
	public int CountPaging(Paging paging) throws Exception;
	
	//검색목록
	public List<NoticeDTO> Search(SearchPaging searchPaging) throws Exception;
	
	//검색된 게시글 갯수구하기
	public int CountSearch(SearchPaging searchPaging) throws Exception;
}
