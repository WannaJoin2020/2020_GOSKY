package kr.co.gugu.dao;

import java.util.List;

import kr.co.gugu.domain.FreeBoardDTO;
import kr.co.gugu.domain.Paging;
import kr.co.gugu.domain.ReplyDTO;
import kr.co.gugu.domain.SearchPaging;

public interface FreeBoardDAO {

	//게시글목록
		public List<FreeBoardDTO> FreeBoardList() throws Exception;
	
	//게시글작성
		public int FreeBoardWrite(FreeBoardDTO dto) throws Exception;
	
	//게시글보기
		public FreeBoardDTO FreeBoardDetail(int bno) throws Exception;
	
	//게시글수정
		public int FreeBoardUpdate(FreeBoardDTO dto) throws Exception;
	
	//게시글삭제
		public int FreeBoardDelete(int bno) throws Exception;
	
	//존재값 유무확인
		public int FreeBoardExist(int bno) throws Exception;

	// 조회수 증가
	public int ReadCnt(int bno) throws Exception;

	//페이징처리
	public List<FreeBoardDTO> Paging(Paging paging) throws Exception;
	
	//페이징처리 _전체게시글 갯수 구하기
	public int CountPaging(Paging paging) throws Exception;
	
	//검색목록
	public List<FreeBoardDTO> Search(SearchPaging searchPaging) throws Exception;
	
	//검색된 게시글 갯수구하기
	public int CountSearch(SearchPaging searchPaging) throws Exception;

	public List<ReplyDTO> ReplyList(int rno) throws Exception;

	public int ReplyWrite(ReplyDTO replyDTO) throws Exception;

	public int ReplyUpdate(ReplyDTO replyDTO) throws Exception;

	public int ReplyDelete(int rno) throws Exception;
}
