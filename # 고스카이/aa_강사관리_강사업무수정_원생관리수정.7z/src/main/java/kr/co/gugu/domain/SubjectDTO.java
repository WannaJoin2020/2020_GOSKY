package kr.co.gugu.domain;

public class SubjectDTO {
   private int sno;
   private String sname;
   private String stime;
   private String teacher;
   private String content;
   private int status;
   private int ssort;

   public int getSno() {
      return sno;
   }
   public void setSno(int sno) {
      this.sno = sno;
   }
   public String getSname() {
      return sname;
   }
   public void setSname(String sname) {
      this.sname = sname;
   }
   
   public String getStime() {
      return stime;
   }
   public void setStime(String stime) {
      this.stime = stime;
   }
   public String getTeacher() {
      return teacher;
   }
   public void setTeacher(String teacher) {
      this.teacher = teacher;
   }
   public String getContent() {
      return content;
   }
   public void setContent(String content) {
      this.content = content;
   }
   
   public int getStatus() {
      return status;
   }
   public void setStatus(int status) {
      this.status = status;
   }
   public int getSsort() {
      return ssort;
   }
   public void setSsort(int ssort) {
      this.ssort = ssort;
   }
   
   
   
}