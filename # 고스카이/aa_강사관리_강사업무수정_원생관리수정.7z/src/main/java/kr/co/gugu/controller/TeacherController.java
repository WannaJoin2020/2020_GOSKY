package kr.co.gugu.controller;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import kr.co.gugu.dao.TeacherDAO;
import kr.co.gugu.domain.MemberDTO;
import kr.co.gugu.domain.PageMaker;
import kr.co.gugu.domain.Paging;
import kr.co.gugu.domain.SearchPaging;
import kr.co.gugu.domain.SubjectDTO;
import kr.co.gugu.domain.TeacherDTO;
import kr.co.gugu.service.TeacherService;

@Controller
public class TeacherController {

	@Inject
	TeacherService teacherService;
	TeacherDAO teacherDAO;

	// 강사추가
	@RequestMapping(value = "/TeacherAdd", method = RequestMethod.GET)
	public String TeacherAdd() {
		return "teacher/TeacherAdd";
	}
	
	@RequestMapping(value = "/TeacherAdd", method = RequestMethod.POST)
	public String TeacherAdd(@ModelAttribute MemberDTO member) {
		teacherService.TeacherAdd(member);
		return "member/login";
	}

	// 강사검색
	@RequestMapping(value = "/TeacherSearch", method = RequestMethod.GET)
	public String TeacherSearch(Model model,HttpSession session, 
			@ModelAttribute("searchPaging") SearchPaging searchPaging) throws Exception {
//		String fromid = (String) session.getAttribute("userID");
		PageMaker pageMaker = new PageMaker();
		
		pageMaker.setPaging(searchPaging);

		pageMaker.setTotalCount(teacherService.CountSearch(searchPaging));
		model.addAttribute("TeacherList", teacherService.Search(searchPaging));
		model.addAttribute("pageMaker", pageMaker);

		return "/teacher/TeacherSearch";
	}
	
//	// 강사정보보기
//		@RequestMapping(value = "/TeacherselfDetail", method = RequestMethod.GET)
//		public ModelAndView TeacherSelfDetail(HttpSession session) throws Exception {
//			ModelAndView mav = new ModelAndView();
//			String mid =(String) session.getAttribute("userID");
//			mav.addObject("member", teacherService.TeacherMember(mid));
//			mav.addObject("teacher", teacherService.TeacherTeacher(mid));
//			mav.addObject("subject", teacherService.TeacherSubject(mid));
//			mav.setViewName("/teacher/TeacherDetail");
//			return mav;
//		}


	// 강사정보보기
	@RequestMapping(value = "/TeacherDetail", method = RequestMethod.GET)
	public ModelAndView TeacherDetail(@RequestParam("mid") String mid) throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.addObject("member", teacherService.TeacherMember(mid));
		mav.addObject("teacher", teacherService.TeacherTeacher(mid));
		mav.addObject("subject", teacherService.TeacherSubject(mid));
		mav.setViewName("/teacher/TeacherDetail");
		return mav;
	}
	
	// 강사정보 업데이트
	@RequestMapping(value = "/MemberUpdate", method = RequestMethod.POST)
	public String MemberUpdate(MemberDTO member) throws Exception {
		int r = teacherService.MemberUpdate(member);
		if (r > 0) {
			return "redirect:TeacherInfoList";
		}
		return "/teacher/TeacherDetail";
	}
	
	// 강사소개 업데이트
		@RequestMapping(value = "/TeacherUpdate", method = RequestMethod.POST)
		public String TeacherUpdate(TeacherDTO teacher, @RequestParam("tno") int tno) throws Exception {
			teacher.setTno(tno);
			int r = teacherService.TeacherUpdate(teacher);
			System.out.println(r);
			if (r > 0) {
				return "redirect:TeacherInfoList";
			}
			return "/teacher/TeacherDetail";
		}
		
		// 과목업데이트
		@RequestMapping(value = "/SubjectUpdate", method = RequestMethod.POST)
		public String SubjectUpdate(SubjectDTO subjectDTO) throws Exception {
			int r = teacherService.SubjectUpdate(subjectDTO);
			if (r > 0) {
				return "redirect:TeacherSearch";
			}
			return "/teacher/TeacherDetail";
		}
		
	// 페이징처리
	@RequestMapping(value = "/TeacherPaging", method = RequestMethod.GET)
	public String TeacherPaging(Model model, Paging paging) throws Exception {
		model.addAttribute("paging", teacherService.Paging(paging));
		return "/teacher/TeacherSearch";
	}

	// 강사추가
	@RequestMapping(value = "/SubjectAdd", method = RequestMethod.GET)
	public String SubjectAdd() {
		return "teacher/SubjectAdd";
	}
	
	@RequestMapping(value = "/SubjectAdd", method = RequestMethod.POST)
	public String SubjectAdd(@ModelAttribute SubjectDTO subjectDTO) {
		teacherService.SubjectAdd(subjectDTO);
		return "redirect:TeacherSearch";
	}
	
}
