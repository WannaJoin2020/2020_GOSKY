package kr.co.gugu.dao;

import java.util.List;

import kr.co.gugu.domain.MemberDTO;
import kr.co.gugu.domain.Paging;
import kr.co.gugu.domain.SearchPaging;
import kr.co.gugu.domain.SubjectDTO;
import kr.co.gugu.domain.TeacherDTO;

public interface TeacherDAO {

	// 원생추가
	public int TeacherAdd(MemberDTO member);
	
//	// 강사리스트 + 검색처리
//	public List<TeacherDTO> TeacherSearch() throws Exception;
//	
//	public List<SubjectDTO> SubjectSearch() throws Exception;

	//상세보기_회원
	public MemberDTO TeacherMember(String mid);
	
	//상세보기_강사
	public TeacherDTO TeacherTeacher(String mid);

	//상세보기_과목
//	public List<SubjectDTO> TeacherSubject();
	public List<SubjectDTO> TeacherSubject(String teacher);

	// 회원 업데이트
	public int MemberUpdate(MemberDTO member);

	// 강사 업데이트
	public int TeacherUpdate(TeacherDTO teacher);

	// 과목 업데이트
	public int SubjectUpdate(SubjectDTO subjectDTO);

	//과목추가
	public int SubjectAdd(SubjectDTO subjectDTO);

	// 페이징처리
	public List<MemberDTO> Paging(Paging paging) throws Exception;

	// 페이징처리 _전체게시글 갯수 구하기
	public int CountPaging(Paging paging) throws Exception;

	// 검색목록
	public List<MemberDTO> Search(SearchPaging searchPaging) throws Exception;

	// 검색된 게시글 갯수구하기
	public int CountSearch(SearchPaging searchPaging) throws Exception;

}
