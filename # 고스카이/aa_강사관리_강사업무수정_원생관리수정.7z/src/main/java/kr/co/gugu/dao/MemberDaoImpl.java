package kr.co.gugu.dao;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.gugu.domain.MemberDTO;

@Repository
public class MemberDaoImpl implements MemberDAO{

	private final String namespace = "mappers.MemberMapper";
	
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public int checkDuplicatedId(String mid) {
		return sqlSession.selectOne(namespace + ".countById", mid);
	}

	@Override
	public int checkDuplicatedEmail(String memail) {
		return sqlSession.selectOne(namespace + ".countByEmail", memail);
	}

	@Override
	public int addMember(MemberDTO dto) {
		return sqlSession.insert(namespace + ".insertMember", dto);
	}

	@Override
	public int addMemberSNS(MemberDTO dto) {
		return sqlSession.insert(namespace + ".insertMemberBySns", dto);
	}

	@Override
	public MemberDTO getUserInfo(String id) {
		return sqlSession.selectOne(namespace + ".getUserInfo", id);
	}

	@Override
	public int checkIdAndPassword(Map<String, String> map) {
		return sqlSession.selectOne(namespace + ".countByIdAndPw", map);
	}

}
