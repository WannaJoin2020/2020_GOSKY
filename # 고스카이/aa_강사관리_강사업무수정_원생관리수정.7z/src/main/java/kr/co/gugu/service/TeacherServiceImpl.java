package kr.co.gugu.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import kr.co.gugu.dao.TeacherDAO;
import kr.co.gugu.domain.MemberDTO;
import kr.co.gugu.domain.TeacherDTO;
import kr.co.gugu.domain.SearchPaging;
import kr.co.gugu.domain.SubjectDTO;

@Service
public class TeacherServiceImpl implements TeacherService {

	@Inject
	TeacherDAO teacherDAO;

	//원생추가
	@Override
	public int TeacherAdd(MemberDTO memberDTO) {
		return teacherDAO.TeacherAdd(memberDTO);
	}
	
//	// 강사리스트 + 검색처리
//	@Override
//	public List<TeacherDTO> TeacherSearch() throws Exception {
//		return teacherDAO.TeacherSearch();
//	}
//	
//	@Override
//	public List<SubjectDTO> SubjectSearch() throws Exception {
//		return teacherDAO.SubjectSearch();
//	}


	@Override
	public MemberDTO TeacherMember(String mid) {
		return teacherDAO.TeacherMember(mid);
	}
	
	@Override
	public TeacherDTO TeacherTeacher(String mid) {
		return teacherDAO.TeacherTeacher(mid);
	}

	@Override
	public List<SubjectDTO> TeacherSubject(String teacher) {
		return teacherDAO.TeacherSubject(teacher);
	}

	@Override
	public List<MemberDTO> Paging(kr.co.gugu.domain.Paging paging) throws Exception {
		return teacherDAO.Paging(paging);
	}

	@Override
	public int CountPaging(kr.co.gugu.domain.Paging paging) throws Exception {
		return teacherDAO.CountPaging(paging);
	}

	@Override
	public List<MemberDTO> Search(SearchPaging searchPaging) throws Exception {
		return teacherDAO.Search(searchPaging);
		
	}

	@Override
	public int CountSearch(SearchPaging searchPaging) throws Exception {
		return teacherDAO.CountSearch(searchPaging);
	}

	@Override
	public int MemberUpdate(MemberDTO member) {
		return teacherDAO.MemberUpdate(member);
	}

	public int TeacherUpdate(TeacherDTO teacher) {
		return teacherDAO.TeacherUpdate(teacher);
	}

	@Override
	public int SubjectUpdate(SubjectDTO subjectDTO) {
		return teacherDAO.SubjectUpdate(subjectDTO);
	}

	@Override
	public int SubjectAdd(SubjectDTO subjectDTO) {
		return teacherDAO.SubjectAdd(subjectDTO);
	}

//	@Override
//	public List<SubjectDTO> TeacherSubject() {
//		return teacherDAO.TeacherSubject();
//	}


}
