package kr.co.gugu;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import kr.co.gugu.dao.FreeBoardDAO;
import kr.co.gugu.dao.NoticeDAO;
import kr.co.gugu.domain.FreeBoardDTO;
import kr.co.gugu.domain.NoticeDTO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/**/root-context.xml" })
public class NoticeCreate {

	@Inject
	private NoticeDAO noticeDAO;
	private FreeBoardDAO freeBoardDAO;

//	@Test
//	public void testInsert() throws Exception {
//
//		NoticeDTO noticeDTO = null;
//		for (int i = 1; i < 1000; i++) {
//			noticeDTO= new NoticeDTO();
//			noticeDTO.setBtitle("Test 제목[" + i + "]");
//			noticeDTO.setBcontent("Test 내용[" + i + "]");
//			noticeDTO.setMid("Test 작성자[" + i + "]");
//
//			noticeDAO.NoticeWrite(noticeDTO);
//		}
//	}
	
	@Test
	public void testInsert2() throws Exception {

		FreeBoardDTO freeBoardDTO = null;
		for (int i = 1; i < 1000; i++) {
			freeBoardDTO= new FreeBoardDTO();
			freeBoardDTO.setBtitle("Test 제목[" + i + "]");
			freeBoardDTO.setBcontent("Test 내용[" + i + "]");
			freeBoardDTO.setMid("Test 작성자[" + i + "]");

			freeBoardDAO.FreeBoardWrite(freeBoardDTO);
		}
	}
}