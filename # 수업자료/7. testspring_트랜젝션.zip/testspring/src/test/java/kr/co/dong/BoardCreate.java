package kr.co.dong;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import kr.co.dong.board.BoardDAO;
import kr.co.dong.board.BoardDTO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/**/root-context.xml" })
public class BoardCreate {

	@Inject
	private BoardDAO boardDAO;

	@Test
	public void testInsert() throws Exception {

//    	 @Inject
//    	 private BoardDTO boardDTO;;

		BoardDTO boardDTO;
		for (int i = 1; i < 1000; i++) {
			boardDTO = new BoardDTO();
			boardDTO.setTitle("Test Title[ " + i + " ]");
			boardDTO.setContent("Test Content[ " + i + " ]");
			boardDTO.setId("Test Id[ " + i + " ]");
			
			boardDAO.register(boardDTO);		//글쓰기
			
			Thread.sleep(1000);
		}
	}
}