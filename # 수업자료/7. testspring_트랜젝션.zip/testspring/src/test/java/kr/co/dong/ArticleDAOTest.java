package kr.co.dong;

import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import kr.co.dong.board.BoardDAO;
import kr.co.dong.board.BoardDTO;
import kr.co.dong.board.Criteria;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/**/root-context.xml" })
public class ArticleDAOTest {

	@Inject
	private BoardDAO boardDAO;

	private static final Logger logger = LoggerFactory.getLogger(ArticleDAOTest.class);

	@Test
	public void testListPaging() throws Exception {
		int page = 3;
		List<BoardDTO> articles = boardDAO.listPaging(page);
		for (BoardDTO board : articles) {
			logger.info(board.getBno() + " : " + board.getTitle() + " : " + board.getContent());
//			System.out.println(board.getBno() + " : " + board.getTitle() + " : " + board.getContent());
		}
	}
	@Test
	public void testListCrieria() throws Exception {
		Criteria criteria = new Criteria();
		criteria.setPage(3);
		criteria.setPerPageNum(20);
		List<BoardDTO> listPaging = boardDAO.listCriteria(criteria);
		for (BoardDTO board : listPaging) {
			System.out.println(board.getBno() + " : " + board.getTitle() + " : " + board.getContent());
		}

	}
}