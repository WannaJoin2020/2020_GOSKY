package kr.co.dong;


import java.sql.Connection;
import java.sql.DriverManager;
import org.junit.Test;

public class jdbcTest {

	static final String DRIVER = "com.mysql.jdbc.Driver";
	static final String URL = "jdbc:mysql://localhost:3306/scott?serverTimezone=UTC";

	static final String USER = "root";
	static final String PW = "12345";

		@Test //jUnit이 테스트함
		public void testConnection() throws Exception{
			Class.forName(DRIVER); //DRIVER라는 이름을 가진 클래스를 찾음
	        
			//DB 계정과 연결된 객체를 Connection 클래스의 인스턴스인 con에 담음
			try(Connection con = DriverManager.getConnection(URL,USER,PW)){ 
				System.out.println(con); //연결된 계정 출력
			}catch(Exception e) { //연결이 되지 않은 예외처리
				e.printStackTrace();
			}
		}	
	}