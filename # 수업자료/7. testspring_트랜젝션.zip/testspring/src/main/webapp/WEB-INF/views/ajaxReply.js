//<%@ page language="java" contentType="text/html; charset=UTF-8"
//    pageEncoding="UTF-8"%>
//<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
////#ajaxreply내용이 html에다가 집어넣으면
////detail1.jsp가 들어온다 section안에 문장을 담아서....
////post타입으로 board/detail1의 값을(내용을)적어준다. ↓↓↓
////result의 컨트롤러 실행한 결과값이 되돌아 온다.
////				success: function(result){
////데이터가 result로 쌓인다
//
//	$(document).ready(function() {
//			console.log("1");
//			
//			var str="<h1>댓글목록</h1> "
//			$("#ajxReply").html(str);
//			$.ajax({
//				type:"post",
//				url:"detail1",	//어디
//				data : {bno:${board.bno}},	//무슨데이터를 실어 갈거니
//
//				success: function(data){
//					alert(data);
//					var str="<div>자 여기 문서를 작성합니다"
//					str = str+ "<br>문서<br>";
//					str = str+ "<br>꾸미기<br>";
//					str = str+ "<br>detail1.jsp의 내용을<br>";
//					$("#ajaxReply").html(result);
//				},
//				error:function(data){
//					alert("에러가 발생했습니다.")
//				}
//			});
//		});