/*
 * mybatis를 사용하고 있기 때문에 mybatis를 호출한다
 * ------> 즉 , sqlsession을 사용한다
 * 
 * 
 */
package kr.co.dong.emp;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class EmpDAOImpl implements EmpDAO {

	@Inject
	private SqlSession sqlSession;

	// final로 선언하면 변경이 안된다. 나중에 empMapper가 길어질 경우
	private static final String nameSpace = "empMapper";

	@Override
	public int printCount() throws Exception {
		return sqlSession.selectOne(nameSpace + ".cnt");
		// namespace가 empmapper로 되어있고, 그 안에 cnt
	}

	@Override
	public List<EmpDTO> listAll() throws Exception {
		return null;
	}

	@Override
	public void list() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void add() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete() throws Exception {
		// TODO Auto-generated method stub
		
	}

	

}
