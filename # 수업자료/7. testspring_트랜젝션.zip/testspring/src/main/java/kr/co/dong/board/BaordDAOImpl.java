package kr.co.dong.board;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class BaordDAOImpl implements BoardDAO {

	@Inject
	private SqlSession sqlSession;
	//private static final String namespace="";
	//private static final String b="board;"
	
	//페이징처리
	@Override
	public List<BoardDTO> listPaging(int page) throws Exception {
		if(page<=0) {
			page=1;
		}
		page=(page-1)*10;
		return sqlSession.selectList("board.listPaging", page);
	}
	
	@Override
	public List<BoardDTO> listCriteria(Criteria criteria) throws Exception {
		// TODO Auto-generated method stub
		return sqlSession.selectList("board.listCriteria", criteria);
	}
	
	//전체조회	
	@Override
	public List<BoardDTO> list() throws Exception {
		return sqlSession.selectList("board.list");
//		return sqlSession.selectList(nameSpace + ".list")
	}

	@Override
	public int updateReadCnt(int bno) throws Exception {
		return sqlSession.update("board.updateReadCnt",bno);
//		return sqlSession.selectList(nameSpace + ".updateReadCnt", bno)

	}

	@Override
	public BoardDTO getDetail(int bno) throws Exception {
		return sqlSession.selectOne("board.detail",bno);
	}
	//글쓰기
	@Override
	public int register(BoardDTO boardDTO) throws Exception {
		return sqlSession.insert("board.register",boardDTO);
	}
	
	@Override
	public int update(BoardDTO dto) throws Exception {
		return sqlSession.update("board.update", dto);
	}

	@Override
	public int delete(int bno) throws Exception {
		return sqlSession.update("board.delete", bno);
	}
	//로그인
	@Override
	//#이 있으면 dao에 전달할 값이 들어가야 한다  (map)
	public Map login(Map<String, String> map) throws Exception {
		return sqlSession.selectOne("board.login", map);
	}
	
//TODO
	//댓글조회
	@Override
	public List<BoardReply> getDetail1(int bno) throws Exception {
		return sqlSession.selectList("board.detail1", bno);
	}
	//댓글작성
	@Override
	public int reply(BoardReply boardreply) throws Exception {
		return sqlSession.insert("board.reply", boardreply);
	}
	//댓글수정(초기화면)
	@Override
	public BoardReply detailReply(int reno) throws Exception {
		return sqlSession.selectOne("board.detailReply", reno);
	}
	//댓글수정
	@Override
	public int replyupdate(BoardReply boardreply) throws Exception {
		return sqlSession.update("board.replyupdate", boardreply);
	}
	//댓글삭제
	@Override
	public int replyDelete(int reno) throws Exception {
		return sqlSession.delete("board.replyDelete", reno);
	}

}
