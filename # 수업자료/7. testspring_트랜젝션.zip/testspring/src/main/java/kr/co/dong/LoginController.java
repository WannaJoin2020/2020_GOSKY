package kr.co.dong;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import kr.co.dong.domain.LoginVO;



@Controller
public class LoginController {
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

	// ModelAndView
	@RequestMapping(value="/login/loginForm", method= RequestMethod.GET)
	public ModelAndView loginForm() {
		logger.info("여기는 로그인폼이동입니다.");
		System.out.println("1");
		//return "login/loginForm";
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("login/loginForm");
		
		return mav;		
	}

	@RequestMapping(value="/login/login", method = RequestMethod.POST)
	public ModelAndView login(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("login/result");  // view
		
		String userID = request.getParameter("userID");
		String userName = request.getParameter("userName");
		
		mav.addObject("userID",userID);    //모델 데이터전달자
		mav.addObject("userName",userName);// 데이터전달자
		
		return mav;
	}
	
	// request한 파라미터를 각각 전달받는 방법2
	// @RequestParam
	@RequestMapping(value="/login/login2", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView login2(@RequestParam("userID") String userID,
			@RequestParam("userName")String userName,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		ModelAndView mav = new ModelAndView();
		
		mav.addObject("userID",userID);
		mav.addObject("userName",userName);
		mav.setViewName("login/result");
		return mav;
	}
	//request한 파라미터를 각각 전달받는 방법3
	//@RequestParam Map<>
	@RequestMapping(value="/login/login3",method= RequestMethod.POST)
	public ModelAndView login3(@RequestParam Map<String,String> info,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		logger.info("userID : " + info.get("userID"));
		logger.info("userName : " + info.get("userName"));
		ModelAndView mav = new ModelAndView();
		mav.addObject("info", info);
		mav.setViewName("login/result");
		return mav;
	}
	
	//request한 파라미터를 각각 전달받는 방법4
	//@ModelAttribute
	@RequestMapping(value="/login/login4",method = RequestMethod.POST)
	public ModelAndView  login4(@ModelAttribute("info") LoginVO loginVO) {
		logger.info("userID : " + loginVO.getUserID() );
		logger.info("userName : " + loginVO.getUserName());
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("login/result");
		return mav;
	}
//	public ModelAndView  login4(LoginVO loginVO) {
//		logger.info("userID : " + loginVO.getUserID() );
//		logger.info("userName : " + loginVO.getUserName());
//		
//		ModelAndView mav = new ModelAndView();
//		mav.addObject("info",loginVO);
//		mav.setViewName("login/result");
//		return mav;
//	}
}













