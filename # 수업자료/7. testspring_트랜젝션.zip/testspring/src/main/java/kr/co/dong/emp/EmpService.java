/*
 * dao에서는 각각 처리
 * 글 읽기 처리 할 때 조회수 증가 dao, 글읽기를 하나로 가지고 움직일 수 있도록 처리
 *  
 *  
 */
package kr.co.dong.emp;

import java.util.List;

public interface EmpService {
	//데이터베이스를 접근하는 것이기 때문에 예외가 발생하므로 throws Exception;

	//인원수
	public int printCount() throws Exception;
	//전체조회
	public List<EmpDTO> listAll() throws Exception;
	//일반조회
	public void list() throws Exception;
	//추가
	public void add() throws Exception;
	//수정
	public void update() throws Exception;
	//삭제
	public void delete() throws Exception;
	//조회수
}