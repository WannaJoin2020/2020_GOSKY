package kr.co.dong.board;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service 		
//service는 inject에 있는 dao를 사용합니다 라고 하고 있다
public class BaordServiceImpl implements BoardService{
	@Inject
	private BoardDAO boardDAO;
	
	@Override
	public List<BoardDTO> listCriteria(Criteria criteria) throws Exception {
		return boardDAO.listCriteria(criteria);
	}
	
	//전체목록보기
	@Override
	public List<BoardDTO> list() throws Exception {
		return boardDAO.list();
	}

//	@Override
//	public int updateReadCnt(int bno) throws Exception {
//		return boardDAO.updateReadCnt(bno);
//	}

//	@Override
//	public BoardDTO getDetail(int bno) throws Exception {
//		return boardDAO.getDetail(bno);
//	}
	//트랜젝션 = 롤백  : 진행되다가 잘못되면 이전 작업을 취소시킨다
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor= {RuntimeException.class,Exception.class})
	@Override
	public BoardDTO getDetail(int bno) throws RuntimeException, Exception {
	
		try {
		boardDAO.updateReadCnt(bno);
		
		
		BoardDTO boardDTO = new BoardDTO();
		boardDTO.setBno(bno);
		boardDTO.setId("111111111111111111111111111");
		
		
		boardDAO.update(boardDTO); //에러나는 부분
	}catch(RuntimeException re) {
		re.printStackTrace();
		
		
		
		throw new RuntimeException("Runtime..............");
	}
		return boardDAO.getDetail(bno);
	}
	//글쓰기
	@Override
	public int register(BoardDTO boardDTO) throws Exception {
		return boardDAO.register(boardDTO);
	}
	//글수정
	@Override
	public int update(BoardDTO dto) throws Exception {
		return boardDAO.update(dto);
	}

	@Override
	public int delete(int bno) throws Exception {
		return boardDAO.delete(bno);
	}
	//로그인
	@Override
	public Map login(Map<String, String> map) throws Exception {
		System.out.println("=====================service 출력문");
		return boardDAO.login(map);
	}

	@Override
	public List<BoardReply> getDetail1(int bno) throws Exception {
		return boardDAO.getDetail1(bno);
	}

	@Override
	public int reply(BoardReply boardreply) throws Exception {
		return boardDAO.reply(boardreply);
	}

	@Override
	public int replyupdate(BoardReply boardreply) throws Exception {
		return boardDAO.replyupdate(boardreply);
	}


	@Override
	public BoardReply detailReply(int reno) throws Exception {
		return boardDAO.detailReply(reno);
	}

	@Override
	public int replyDelete(int reno) throws Exception {
		return boardDAO.replyDelete(reno);
	}

}
