/*
 *  EMP테이블에 관련된 기능을 작성
 *  1. 테이블의 인원수 구하기
 *  2. 전체조회....
 *  3. 선택된 글 조회	(각각 단일기능)
 *  4. 선택된 글 조회수 증가		(각각 단일기능 으로 추가되어야 한다)
 *  
 *  	
 */
package kr.co.dong.emp;

import java.util.List;

public interface EmpDAO {
	//데이터베이스를 접근하는 것이기 때문에 예외가 발생하므로 throws Exception;
	//인원수
	public int printCount() throws Exception;
	//전체조회
	public List<EmpDTO> listAll() throws Exception;
	//일반조회
	public void list() throws Exception;
	//추가
	public void add() throws Exception;
	//수정
	public void update() throws Exception;
	//삭제
	public void delete() throws Exception;
	//조회수
}
