CREATE TABLE `board` (
  `bno` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) DEFAULT NULL,
  `content` varchar(45) DEFAULT NULL,
  `id` varchar(45) DEFAULT NULL,
  `regdate` datetime DEFAULT NULL,
  `readcnt` int(11) DEFAULT NULL,
  `etc` varchar(45) DEFAULT NULL,
  `del` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`bno`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
