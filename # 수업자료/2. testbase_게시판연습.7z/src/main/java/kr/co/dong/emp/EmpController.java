/*
 * COntroller는 Service를 호출한다.
 */
package kr.co.dong.emp;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class EmpController {
	@Inject
	private EmpService service;
	
	@RequestMapping("/empcount")
	public String empCount(Model model,HttpServletRequest request) throws Exception {
		int count = service.printCount();
		model.addAttribute("cnt", count);
		//model.addAttribute("cnt", service.printCount());
		return "home";
	}
	

}
