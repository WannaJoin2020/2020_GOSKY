/*
 * 글읽기처리 할때 조회수증가DAO, 글읽기 
 */
package kr.co.dong.emp;

import java.util.List;

public interface EmpService {
	public int printCount() throws Exception;
	public List<EmpDTO> listAll() throws Exception;
}
