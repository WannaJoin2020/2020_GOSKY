/*
 * userno int AI PK 
id varchar(45) 
password varchar(45) 
name varchar(45

bno int AI PK 
title varchar(45) 
content varchar(45) 
id varchar(45) 
regdate datetime 
readcnt int 
etc varchar(45
 */

package kr.co.dong.board;

import java.util.Date;

public class BoardDTO {

	private int bno;				//글번호
	private String title;			//제목
	private String content;			//내용
	private String id;				//아이디
	private Date regdate;				//작성날짜
	private int readcnt;			//조회수
	private String etc;				//기타
	
	
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	public int getReadcnt() {
		return readcnt;
	}
	public void setReadcnt(int readcnt) {
		this.readcnt = readcnt;
	}
	public String getEtc() {
		return etc;
	}
	public void setEtc(String etc) {
		this.etc = etc;
	}
	
}
