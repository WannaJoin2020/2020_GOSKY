package kr.co.dong.board;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class BoardController {
	@Autowired
	private BoardService boardService;
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);

	// 로그인화면
	@RequestMapping(value = "board/login", method = RequestMethod.GET)
	public String login() {
		logger.info("login view 이동");
		return "login";
	}

	// 로그인실행
	@RequestMapping(value = "/board/login", method = RequestMethod.POST)
	public String login(@RequestParam Map<String, String> map, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		request.setCharacterEncoding("utf-8");
		logger.info("==============login Controller ==============");
		Map user = boardService.login(map);
		if (user == null) { // 관리자가 아닙니다
			logger.info("로그인안됨");
			return "redirect:login";
		} else {
			session.setAttribute("user", user);
			logger.info("로그인됨");
			return "redirect:/"; // 첫 페이지로 이동하세요
		}
	}

	// 로그아웃
	@RequestMapping(value = "board/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

	// 전체조회
	@RequestMapping(value = "board/list", method = RequestMethod.GET)
	public ModelAndView list() throws Exception {
		logger.info("==================list");
		ModelAndView mav = new ModelAndView();
		List<BoardDTO> list = boardService.list();
		mav.addObject("list", list);
		mav.setViewName("list");
		return mav;
	}

	// 글쓰기(값이 없으면 글쓰기 화면으로 이동)
	@RequestMapping(value = "board/register", method = RequestMethod.GET)
	public String register() {
		logger.info("글쓰기이동");
		return "register";
	}

	// 글쓰기(값이 있으면 list화면으로 이동)
	@RequestMapping(value = "board/register", method = RequestMethod.POST)
	public String register(BoardDTO boardDTO, RedirectAttributes rttr) throws Exception {
		int r = boardService.register(boardDTO);
		if (r > 0) {
			rttr.addFlashAttribute("msg", "글쓰기 성공하였습니다.");
		}
		return "redirect:list";
	}

	// 상세보기
	@RequestMapping(value = "board/detail", method = RequestMethod.GET)
	// request 되어지는 (int bno)를 requestparam(bno)로 받겠습니다.
	public String detail(@RequestParam("bno") int bno, Model model, RedirectAttributes rttr) throws Exception {
		boardService.updateReadCnt(bno);// 조회수
		BoardDTO boardDTO = boardService.getDetail(bno);
//		if (boardDTO == null) {
//			rttr.addFlashAttribute("msg", "값이 존재하지 않습니다");
//			return "redirect:list";
//		} else {
		model.addAttribute("board", boardDTO);

		// 댓글목록조회
		List<BoardReply> replylist = boardService.getDetail1(bno);
		model.addAttribute("list", replylist);
		return "detail";
	}
	@ResponseBody
	@RequestMapping(value = "board/detail1", method = RequestMethod.POST)
//	board/detail1으로 들어올 때 @requestparam bno로 받아서 int bno로 쓰겠다
	public List<BoardReply> detail1(@RequestParam("bno") int bno, Model model) throws Exception {
		return boardService.getDetail1(bno);
	}
	
	// 댓글작성(초기화면)
	@RequestMapping(value = "board/reply", method = RequestMethod.GET)
	public String reply() {
		return "reply";
	}

	// 수정
	@RequestMapping(value = "board/update", method = RequestMethod.GET)
	public String update(@RequestParam("bno") int bno, Model model) throws Exception {
		BoardDTO board = boardService.getDetail(bno);
		model.addAttribute("board", board);
		return "update";
	}

	// 수정
	@RequestMapping(value = "board/update", method = RequestMethod.POST)
	public String update(BoardDTO dto, RedirectAttributes rttr) throws Exception {
		int r = boardService.update(dto);
		if (r > 0) {
			rttr.addFlashAttribute("msg", "수정에 성공하였습니다.");
		}
		return "redirect:list";
	}

	// 삭제
	@RequestMapping(value = "board/delete", method = RequestMethod.GET)
	public String update(@RequestParam("bno") int bno, RedirectAttributes rttr) throws Exception {
		int r = boardService.delete(bno);
		if (r > 0) {
			rttr.addFlashAttribute("msg", "글이 삭제되었습니다.");
		}
		return "redirect:list";
		// return "redirect:detail?bno="+bno;
//		board/detail1으로 들어올 때 @requestparam bno로 받아서 int bno로 쓰겠다
	}

	// 댓글작성
	@RequestMapping(value = "board/reply", method = RequestMethod.POST)
	public String reply(BoardReply boardreply) throws Exception {
		int r = boardService.reply(boardreply);
		// 삽입, 삭제, 수정은 성공하면 영향받은 행의 갯수를 리턴한다
		// r>0 크면 성공이고, 그렇지 않으면 실패
		// 새로고침을 하게되면 실행 되지 않아야 않도록 redirect를 사용해야한다
		// 이전 요청이 발생되지 않게 하기 위해.. redirect
		// 이전 요청을 다시 발생시켜도 되는 경우에는 forwarding 해야함
		if (r > 0) {
			return "redirect:detail?bno=" + boardreply.getBno();
		}
		return "reply";
	}

	// 댓글수정(초기화면)
	@RequestMapping(value = "board/replyupdate", method = RequestMethod.GET)
	public String replyUpdate(@RequestParam("reno") int reno, Model model) throws Exception {
		BoardReply boardreply = boardService.detailReply(reno);
		model.addAttribute("boardreply", boardreply);
		return "replyupdate";
	}

	// 댓글수정
	@RequestMapping(value = "board/replyupdate", method = RequestMethod.POST)
	public String replyUpdate(BoardReply boardreply) throws Exception {
		int r = boardService.replyupdate(boardreply);
		if (r > 0) {
			return "redirect:list";
		}
		return "redirect:list";
	}

	// 댓글삭제
//	@RequestMapping(value = "board/replydelete", method = RequestMethod.GET)
//	public String replydelete(@RequestParam("bno") int bno, @RequestParam("reno") int reno, RedirectAttributes rttr)
//			throws Exception {
//		int r = boardService.replyDelete(reno);
//		if (r > 0) {
//			rttr.addFlashAttribute("msg", "댓글이 삭제되었습니다.");
//			return "redirect:detail?bno=" + bno;
//		}
//		return "redirect:list";
//	}
//=========================== ajax ===============================
	// ajax 댓글코드 (목록조회, 수정, 삭제)
	
	@ResponseBody
	@RequestMapping(value = "board/replyDelete", method = RequestMethod.POST)
	public Map<String, Object> replyDelete(@RequestParam("reno") int reno) throws Exception {
		Map<String, Object> result = new HashMap<>();
		try {
			boardService.replyDelete(reno); // 수정 또는 삭제
			result.put("status", "ok");
		} catch (Exception e) {
			e.printStackTrace();
			result.put("status", "fail");
		}
		return result;
	}
}
