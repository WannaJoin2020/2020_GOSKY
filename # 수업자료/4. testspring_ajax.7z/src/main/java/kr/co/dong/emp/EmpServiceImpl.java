/*
 * service는 dao 호출을 담당한다 
 */

package kr.co.dong.emp;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

@Service
public class EmpServiceImpl implements EmpService {

	@Inject
	private EmpDAO dao;

	@Override
	public int printCount() throws Exception {
		return dao.printCount();
	}

	@Override
	public List<EmpDTO> listAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void list() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void add() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete() throws Exception {
		// TODO Auto-generated method stub
		
	}

}
