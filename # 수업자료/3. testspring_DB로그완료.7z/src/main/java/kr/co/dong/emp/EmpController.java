/*
 * controller는 service를 담당한다
 * 가장먼저 어노테이션 달아주세요 @Controller
 */
package kr.co.dong.emp;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class EmpController {
	@Inject
	private EmpService service;
	
	//사용자가 empcount를 받아서 home으로 return 한다
	
	@RequestMapping("/empcount")	
	public String empCount(Model model, HttpServletRequest request) throws Exception {
		int count = service.printCount();
		model.addAttribute("cnt", count);
		//위에 2줄 한번에 작성하려면 이렇게도 쓴다
		//model.addAttribute("cnt", service.printCount());
		return "home";
	}
	

}
