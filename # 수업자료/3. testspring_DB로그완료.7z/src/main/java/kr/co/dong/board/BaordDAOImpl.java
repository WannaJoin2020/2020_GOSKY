package kr.co.dong.board;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class BaordDAOImpl implements BoardDAO {

	@Inject
	private SqlSession sqlSession;
	
	//전체조회	
	@Override
	public List<BoardDTO> list() throws Exception {
		return sqlSession.selectList("board.list");
	}

	@Override
	public int updateReadCnt(int bno) throws Exception {
		return sqlSession.update("board.updateReadCnt",bno);
	}

	@Override
	public BoardDTO getDetail(int bno) throws Exception {
		return sqlSession.selectOne("board.detail",bno);
	}
	//글쓰기
	@Override
	public int register(BoardDTO boardDTO) throws Exception {
		return sqlSession.insert("board.register",boardDTO);
	}
	
	@Override
	public int update(BoardDTO dto) throws Exception {
		return sqlSession.update("board.update", dto);
	}

	@Override
	public int delete(int bno) throws Exception {
		return sqlSession.update("board.delete", bno);
	}
	//로그인
	@Override
	//#이 있으면 dao에 전달할 값이 들어가야 한다  (map)
	public Map login(Map<String, String> map) throws Exception {
		return sqlSession.selectOne("board.login", map);
	}
}
