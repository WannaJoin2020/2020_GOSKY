package com.poe.test.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.poe.test.HomeController;
import com.poe.test.domain.Board;
import com.poe.test.domain.BoardReply;

//DAO 입니다. 디비 사용할래요.
@Repository
public class BoardDaoImpl implements BoardDao{
	private static final Logger logger = LoggerFactory.getLogger(BoardDaoImpl.class);
	
	@Autowired
	private SqlSession sqlSession;  // 마이바티스 사용

	@Override
	public Map login(Map<String, Object> map) {
		logger.info("login DAO");
		return sqlSession.selectOne("board.login",map );
	}

	@Override
	public int maxNum() {
		Integer r = 0 ;
		r = sqlSession.selectOne("board.maxNum");
		return r;
	}

	@Override
	public List<Board> list() {
		logger.debug("board list");
		return sqlSession.selectList("board.list");
	}
	@Override
	public int register(Board board) {		
		return sqlSession.insert("board.register",board);
	}

	@Override
	public Board getDetail(int bno) {
		
		return sqlSession.selectOne("board.detail", bno);
	}

	@Override
	public int updateReadcnt(int bno) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int bno) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Board vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int reply(BoardReply boardreply) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<BoardReply> getDetail1(int brdno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int replyupdate(BoardReply vo) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
