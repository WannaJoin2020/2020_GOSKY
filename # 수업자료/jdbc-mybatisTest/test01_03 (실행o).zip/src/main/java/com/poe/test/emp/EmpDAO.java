/* 데이터베이스 emp table에 관련된 기능을 작성
 * 1. emp테이블의 인원수를 구하자.
 * 2. .....
 */
package com.poe.test.emp;

public interface EmpDAO {
	public int printCount() throws Exception;
	//..
	//
}



