package com.poe.test.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.poe.test.domain.Board;
import com.poe.test.domain.BoardReply;

public interface BoardService {
	// 글쓰기 작업을 위한 메소드
	// ip는 입력받을 수 없고 request 객체를 이용해서 구해야 하기 때문에
	// 매개변수가 request 입니다.
	public int register(HttpServletRequest request);

	// 전체 목록을 가져오는 메소드
	public List<Board> list();

	// 상세보기를 위한 메소드
	public Board detail(int bno);

	// 삭제를 위한 메소드
	public int delete(int bno);

	// 수정보기 화면을 위한 메소드
	public Board updateView(int bno);
	
	// 글 수정을 처리하기 위한 메소드
	public int update(HttpServletRequest request);

	// 로그인을 처리하기 위한 메소드
	public Map login(HttpServletRequest request);

	// 댓글쓰기 작업을 위한 메소드
	public int reply(HttpServletRequest request);
    
	//댓글 상세보기를 위한 해당 게시물 번호를 불러오는 메소드
	public List<BoardReply> detail1(int brdno);
	
	//댓글수정을 보기위한 화면 메소드
	public BoardReply updateReplyView(int brdno);
	
	//댓글수정을 보기위한 화면 메소드2
	public BoardReply updateReplyView1(int reno);
	
	//댓글수정을 처리하기 위한 메소드
	public int replyupdate(HttpServletRequest request);
	
}
