package com.poe.test.domain;

public class BoardReply {
	private int brdno; // 게시물 번호

	private int reno; // 댓글번호

	private String rewriter; // 작성자

	private String redeleteflag; // 삭제여부

	private String rememo; // 댓글내용

	private String redate; // 작성일자

	private int recnt; // 조회수

	public int getRecnt() {
		return recnt;
	}

	public void setRecnt(int recnt) {
		this.recnt = recnt;
	}

	public int getReno() {
		return reno;
	}

	public void setReno(int reno) {
		this.reno = reno;
	}

	public String getRewriter() {
		return rewriter;
	}

	public void setRewriter(String rewriter) {
		this.rewriter = rewriter;
	}

	public String getRedeleteflag() {
		return redeleteflag;
	}

	public void setRedeleteflag(String redeleteflag) {
		this.redeleteflag = redeleteflag;
	}

	public String getRememo() {
		return rememo;
	}

	public void setRememo(String rememo) {
		this.rememo = rememo;
	}

	public String getRedate() {
		return redate;
	}

	public void setRedate(String redate) {
		this.redate = redate;
	}

	public void setBrdno(int brdno) {
		this.brdno = brdno;
	}

	public int getBrdno() {

		return brdno;
	}

	@Override
	public String toString() {
		return "BoardReply [brdno=" + brdno + ", reno=" + reno + ", rewriter=" + rewriter + ", redeleteflag="
				+ redeleteflag + ", rememo=" + rememo + ", redate=" + redate + ", recnt=" + recnt + "]";
	}

}
