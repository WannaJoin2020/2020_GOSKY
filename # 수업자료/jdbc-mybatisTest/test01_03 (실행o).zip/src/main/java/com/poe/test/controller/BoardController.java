package com.poe.test.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.poe.test.domain.Board;
import com.poe.test.domain.BoardReply;
import com.poe.test.service.BoardService;

@Controller
public class BoardController {
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Autowired
	private BoardService boardService;
	
	@RequestMapping(value="board/detail",method=RequestMethod.GET)
	public String detail(@RequestParam("bno") int bno,Model model) {
		Board board=boardService.detail(bno);
		model.addAttribute("board", board);
		
		return "detail";
	}
	
	// 1. redirect
	// 새로고침을 했을때 이전 요청이 다시 발생하지 않게 하도록 한다.
	// 2. forward
	// 새로고침을 했을때 이전 요청을 다시 발생시켜도 된다면
	
	//글쓰기1(폼으로)
	@RequestMapping(value="board/register",method=RequestMethod.GET)
	public String register() {
		return "register";
	}
	//글쓰기 2(DB로)
	@RequestMapping(value="board/register",method=RequestMethod.POST)
	public String register(HttpServletRequest request) {
		boardService.register(request);
		return "redirect:list";
	}
	
	// 리스트 설계해봅시다.
	@RequestMapping(value="board/list",method=RequestMethod.GET)
	public String list(Model model) {
		logger.info(" board list");
		List<Board>  list=boardService.list();
		// 데이터 저장
		model.addAttribute("list", list);
		return "list";
	}
		
	@RequestMapping(value="board/login", method= RequestMethod.GET)
	public String login() {
		logger.info("login view 이동");
		return "login";
	}
	
	@RequestMapping(value="board/login", method= RequestMethod.POST)
	public String login(HttpServletRequest request,HttpSession session) {
		logger.info("login 처리");
		// 서비스 호출
		Map map = boardService.login(request);
		logger.info("======");
		if(map == null) {  // 관리자급이 아닙니다.
			
			return "redirect:login";
		}else {
			// 세션 부여
			session.setAttribute("user", map);
			
			return "redirect:/";
		}		
	}
	@RequestMapping(value = "board/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	@RequestMapping(value = "board/delete", method = RequestMethod.GET)
	public String delete(@RequestParam("bno") int bno, RedirectAttributes attr) {
		int r = boardService.delete(bno);
		if (r > 0) {
			attr.addFlashAttribute("msg", "게시글 삭제에 성공했습니다.");
			return "redirect:list";
		}
		// 실패 했을 때는 상세보기로 리다이렉트
		return "redirect:detail?bno=" + bno;
	}

	@RequestMapping(value = "board/update", method = RequestMethod.GET)
	public String update(@RequestParam("bno") int bno, Model model) {
		Board board = boardService.updateView(bno);
		model.addAttribute("board", board);
		return "update";
	}

	@RequestMapping(value = "board/update", method = RequestMethod.POST)
	public String update(HttpServletRequest request, RedirectAttributes attr) {
		int r = boardService.update(request);
		// 수정에 성공하면 목록보기로 이동
		if (r > 0) {
			attr.addFlashAttribute("msg", "수정에 성공 하였습니다.");
			return "redirect:list";
		}
		// 수정에 실패하면 수정보기 화면으로 이동
		return "redirect:update?bno=" + request.getParameter("bno");
	}
	// 댓글쓰기로 워해 댓글 쓰기창으로 넘어가는 창
	@RequestMapping(value = "board/reply", method = RequestMethod.GET)
	public String replyGET(BoardReply boardreply, Model model, HttpSession session) {
		return "reply";
	}

	@RequestMapping(value = "board/reply", method = RequestMethod.POST)
	public String reply(HttpServletRequest request) {
		// 서비스의 메소드를 호출해서 결과를 가져오기
		int re = boardService.reply(request);
		// 삽입, 삭제, 갱신은 성공하면 영향받은 행의 개수를 리턴합니다.
		// re>0 크면 성공이고 그렇지 않으면 실패
		// 새로고침을 했을 때 이전 요청이 다시 발생하지 않도록 하려면
		// redirect로 이동해야 하고 이전 요청을 다시 발생시켜도 되는 경우는
		// forwarding 해야 합니다.
		if (re > 0) {
			return "redirect:detail?bno=" + request.getParameter("bno");
		}
		return "reply";
	}

	@RequestMapping(value = "board/replyupdate", method = RequestMethod.GET)
	public String replyupdate(@RequestParam("brdno") int brdno, Model model) {
		BoardReply boardreply = boardService.updateReplyView(brdno);
		model.addAttribute("boardreply", boardreply);
		return "replyupdate";
	}

	@RequestMapping(value = "board/replyupdate", method = RequestMethod.POST)
	public String replyupdate(HttpServletRequest request, Model model) {
		int re = boardService.replyupdate(request);
		// 수정에 성공하면 목록보기로 이동
		if (re > 0) {
			return "redirect:detail";
		}
		// 수정에 실패하면 수정보기 화면으로 이동
		return "redirect:replyupdate?brdno=" + request.getParameter("brdno");
	}
	
}
