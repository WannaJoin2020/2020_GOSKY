package com.poe.test.common;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

// advice : 공통업무를 지원하는 클래스
@Component
@Aspect
public class LoggerAspect {
	protected Logger log = LoggerFactory.getLogger(LoggerAspect.class);
	String type="";
	
	//@before(해당대상이 호출전)
	@Around("execution(* com.poe.test.emp.*Controller.*(..))")
	public Object logPrint(ProceedingJoinPoint joinPoint) throws Throwable{
		// 핵심업무 실행전
		Object result = null;
		type = joinPoint.getSignature().getDeclaringTypeName();
		long start = System.currentTimeMillis();
//		System.out.println(type);		
		//핵심업무 실행
		result = joinPoint.proceed();
		
		//핵심업무 실행 후
		long end = System.currentTimeMillis();
//		System.out.println("수행시간 : "+ (end-start));
		log.info("->"+type +" : 수행시간 " + (end-start));
		return result;
		
	}

}








