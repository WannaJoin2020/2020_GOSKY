package com.poe.test.emp;

public interface EmpService {
	public int printCount() throws Exception;
}
