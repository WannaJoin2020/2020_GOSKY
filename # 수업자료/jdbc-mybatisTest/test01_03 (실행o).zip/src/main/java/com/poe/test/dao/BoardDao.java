/* Mybatis와 서비스 연결고리
 * 
 */
package com.poe.test.dao;

import java.util.List;
import java.util.Map;

import com.poe.test.domain.Board;
import com.poe.test.domain.BoardReply;

public interface BoardDao {
	// 글쓰기 처리를 위한 메소드
	// 삽입 , 삭제, 갱신 메소드의 리턴 타입은 무조건 int
	public int maxNum();

	public int register(Board board);

	// 전체 목록을 가져오는 메소드
	public List<Board> list();

	// 상세보기 처리를 위한 메소드
	public int updateReadcnt(int bno);

	public Board getDetail(int bno);

	// 글 삭제를 처리하기 위한 메소드
	public int delete(int bno);

	// 글 수정을 처리하기 위한 메소드
	public int update(Board vo);

	// 로그인 처리를 위한 메소드
	public Map login(Map<String, Object> map);

	// 댓글 쓰기를 위한 메소드
	public int reply(BoardReply boardreply);

	// 게시물 번호에 해당하는 댓글번호를 가져오기
	public List<BoardReply> getDetail1(int brdno);

	//댓글 수정 처리를 위한 메소드
	public int replyupdate(BoardReply vo);
}












