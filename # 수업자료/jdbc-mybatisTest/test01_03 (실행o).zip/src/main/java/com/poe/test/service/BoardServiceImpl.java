package com.poe.test.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.poe.test.HomeController;
import com.poe.test.dao.BoardDao;
import com.poe.test.domain.Board;
import com.poe.test.domain.BoardReply;


//Service 클래스라는 것을 알려주고 객체를 자동으로 만들어주는 어노테이션
@Service
public class BoardServiceImpl implements BoardService {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardServiceImpl.class);
	// 동일한 객체가 있으면 자동으로 주입받도록 해주는 어노테이션	
	@Autowired
	private BoardDao boardDao;

	@Override
	public int register(HttpServletRequest request) {
		// 파라미터를 읽어서 Dao 메소드의 매개변수를 만들고 결과를 리턴
		Board board = new Board();
		board.setBno(boardDao.maxNum() + 1);
		// title, content, id 파라미터의 값을 읽어서 대입
		board.setTitle(request.getParameter("title"));
		board.setContent(request.getParameter("content"));
		board.setId(request.getParameter("id"));

		// 클라이언트의 아이피 주소를 가져와서 대입하기
		board.setIp(request.getRemoteAddr());

		return boardDao.register(board);
	}

	@Override
	public List<Board> list() {
		return boardDao.list();
	}

	@Override
	public Board detail(int bno) {
		boardDao.updateReadcnt(bno);
		Board board = boardDao.getDetail(bno);
		return board;
	}

	@Override
	public int delete(int bno) {
		return boardDao.delete(bno);
	}

	@Override
	public Board updateView(int bno) {
		return boardDao.getDetail(bno);
	}

	@Override
	public int update(HttpServletRequest request) {
		Board board = new Board();
		// 파라미터는 문자열로 리턴되므로 정수로 변환해서 bno에 대입
		String bno = request.getParameter("bno");
		board.setBno(Integer.parseInt(bno));

		board.setTitle(request.getParameter("title"));
		board.setContent(request.getParameter("content"));

		board.setIp(request.getRemoteAddr());
		return boardDao.update(board);
	}

	@Override
	public Map login(HttpServletRequest request) {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		map.put("pw", pw);
		return boardDao.login(map);
	}

	@Override
	public int reply(HttpServletRequest request) {
		// 파라미터를 읽어서 Dao 메소드의 매개변수를 만들고 결과를 리턴

		BoardReply boardreply = new BoardReply();
		// rewriter, rememo,redatedatetime, redeleteflag
		boardreply.setBrdno(Integer.parseInt(request.getParameter("bno")));
		System.out.println(boardreply.getBrdno() + "ㅋㅋㅋ");
		boardreply.setRewriter(request.getParameter("rewriter"));
		boardreply.setRememo(request.getParameter("rememo"));

		return boardDao.reply(boardreply);
	}

	// 댓글 상세보기를 위한 게시물 번호를 불러오는 메소드
	@Override
	public List<BoardReply> detail1(int brdno) {
		return boardDao.getDetail1(brdno);
	}
	
	//댓글 수정을 위한 메소드1
	@Override
	public BoardReply updateReplyView(int brdno) {
		return (BoardReply) boardDao.getDetail1(brdno);
	}
	
	//댓글 수정을 위한 메소드2
	@Override
	public BoardReply updateReplyView1(int reno) {
		return (BoardReply) boardDao.getDetail1(reno);
	}
	
	
   
	@Override
	public int replyupdate(HttpServletRequest request) {
		BoardReply boardreply = new BoardReply();
		//파라미터는 문자열로 리턴되므로 정수로 변환해서 brdno에 대입
		String brdno = request.getParameter("brdno");
		boardreply.setBrdno(Integer.parseInt(brdno));
		
		String reno = request.getParameter("reno");
		boardreply.setReno(Integer.parseInt(reno));
		
		boardreply.setRewriter(request.getParameter("rewriter"));
		boardreply.setRememo(request.getParameter("rememo"));
		boardreply.setRedate(request.getParameter("redate"));
		return boardDao.replyupdate(boardreply);
	}	
}
